import pandas as pd
import numpy as np
import os
import time
from timeit import default_timer as timer
def fuzzy_quick_reduct(X,y, alpha):
    """
    基于模糊粗糙集的 FuzzyQuickReduct 属性约简算法
    :param data: DataFrame类型，数据集
    :param alpha: 模糊参数
    :return: 属性约简结果列表
    """
    # 将数据集分为特征矩阵和类别向量
    X = X.values
    y = y.values
    X_normalized = X
    # 初始化属性约简结果列表
    reduct = []
    # 对每一个特征列进行处理
    for i in range(X_normalized.shape[1]):
        # 当前特征列
        A = X_normalized[:, i]
        # 初始化关联矩阵
        R = np.zeros((A.shape[0], A.shape[0]))
        for j in range(A.shape[0]):
            for k in range(j+1, A.shape[0]):
                # 计算关联矩阵中第j行第k列的值
                R[j][k] = R[k][j] = np.exp(-alpha * (A[j] - A[k]) ** 2)
        # 计算关联矩阵每一行的和，用于计算约简度
        row_sum = np.sum(R, axis=1)
        # 计算当前属性的约简度
        red = np.sum(row_sum / A.shape[0])
        # 将当前属性加入属性约简结果列表
        reduct.append((i, red))
    # 按照属性的约简度从大到小排序
    reduct = sorted(reduct, key=lambda x: x[1], reverse=True)
    # 将属性约简结果列表转换成只包含属性序号的列表
    reduct = [x[0] for x in reduct]
    return reduct

FileDirectory=os.getcwd()
ReadAddress=r"H:\PythonProject\MachineLearning\FoodSecurity\Data\ProcessingData\InitialData\InitialData_Normalized.xlsx"
ReadAddress2=r"H:\PythonProject\MachineLearning\FoodSecurity\Data\ProcessingData\InitialData\InitialData.xlsx"
WriteAddress=FileDirectory + r'\ReducedFeatures_FQR.xlsx'
WriteAddress2=FileDirectory + r'\ReducedData_FQR.xlsx'
WriteAddress3=FileDirectory + r'\RunningTime_FQR.xlsx'
fm=pd.read_excel(ReadAddress,sheet_name=None,index_col=0)
fm2=pd.read_excel(ReadAddress2,sheet_name=None,index_col=0)
writer = pd.ExcelWriter(WriteAddress)
writer2 = pd.ExcelWriter(WriteAddress2)
writer3 = pd.ExcelWriter(WriteAddress3)
AllProvince=fm.keys()
ReducedFeatures=pd.DataFrame()
ConsumingTime=pd.Series()
for province in AllProvince:
    df=fm[province]
    print(province)
    X=df.iloc[1:,1:-1]
    y=df['每亩主产品产量'][1:]
    start_time = timer()
    result=fuzzy_quick_reduct(X, y, 0.15)
    end_time = timer()
    run_time=end_time-start_time
    ConsumingTime[province]=run_time
    num_features = 10
    top_features_idx = result[:num_features]
    top_features=X.columns[top_features_idx]
    Temp=pd.Series(top_features)
    Temp.rename(province,inplace=True)
    ReducedFeatures=pd.concat([ReducedFeatures,Temp],axis=1)
    df2=fm2[province]
    selected_data=df2.iloc[:,top_features_idx]
    selected_data=pd.concat([selected_data,df2['每亩主产品产量']],axis=1)
    selected_data=selected_data.iloc[1:,:]
    selected_data.to_excel(writer2,sheet_name=province)
    print("Top {} features: {}".format(num_features, X.columns[top_features_idx]))
writer2.save()
ColumnName = [f'feature {i}' for i in range(1, num_features+1)]
ReducedFeatures=ReducedFeatures.T
ReducedFeatures = ReducedFeatures.rename(columns=dict(zip(ReducedFeatures.columns, ColumnName)))
ReducedFeatures.to_excel(writer)
writer.save()
print(ConsumingTime)
ConsumingTime.rename('特征选择耗时',inplace=True)
ConsumingTime.to_excel(writer3,sheet_name='FuzzyQuickReduct')
writer3.save()
