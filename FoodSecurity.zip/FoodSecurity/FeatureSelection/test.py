import numpy as np
import pandas as pd
import os

def fuzzy_quick_reduct(feature_matrix, class_vector, threshold):
    # Step 1: Compute fuzzy rough membership degree
    rows, cols = feature_matrix.shape
    rough_membership_degree = np.zeros((rows, cols))
    for i in range(rows):
        for j in range(cols):
            if feature_matrix[i,j] >= threshold[j]:
                rough_membership_degree[i,j] = 1
            else:
                rough_membership_degree[i,j] = (threshold[j] - feature_matrix[i,j]) / (threshold[j] - np.min(feature_matrix[:,j]))

    # Step 2: Compute fuzzy positive region
    positive_region = []
    for i in range(rows):
        if class_vector[i] == 1:
            positive_region.append(i)
    positive_region_membership_degree = np.zeros(rows)
    for i in range(rows):
        positive_region_membership_degree[i] = np.min(rough_membership_degree[positive_region, :][:, i])

    # Step 3: Compute reduct
    reduct = []
    for i in range(cols):
        temp_threshold = np.copy(threshold)
        temp_threshold[i] = np.max(feature_matrix[:,i])
        temp_rough_membership_degree = np.zeros((rows, cols))
        for j in range(rows):
            for k in range(cols):
                if feature_matrix[j,k] >= temp_threshold[k]:
                    temp_rough_membership_degree[j,k] = 1
                else:
                    temp_rough_membership_degree[j,k] = (temp_threshold[k] - feature_matrix[j,k]) / (temp_threshold[k] - np.min(feature_matrix[:,k]))
        temp_positive_region_membership_degree = np.zeros(rows)
        for j in range(rows):
            temp_positive_region_membership_degree[j] = np.min(temp_rough_membership_degree[positive_region, :][:, j])
        if np.array_equal(positive_region_membership_degree, temp_positive_region_membership_degree):
            reduct.append(i)
    return reduct

def fuzzy_quick_reduct2(feature_matrix, class_vector, threshold):

    # 计算属性间的相似度
    D = np.zeros((feature_matrix.shape[1], feature_matrix.shape[1]))
    for i in range(feature_matrix.shape[1]):
        for j in range(i, feature_matrix.shape[1]):
            if i == j:
                D[i, j] = 1
            else:
                D[i, j] = np.exp(-np.sum(np.abs(feature_matrix.iloc[:, i] - feature_matrix.iloc[:,
                                                                        j])) / feature_matrix.shape[0])
                D[j, i] = D[i, j]

    # 计算属性的权重
    W = np.zeros(feature_matrix.shape[1])
    for i in range(feature_matrix.shape[1]):
        W[i] = np.sum(D[i]) / feature_matrix.shape[1]

    # 初始化重要度
    imp = np.zeros(feature_matrix.shape[1])

    # 计算属性的重要度
    for i in range(feature_matrix.shape[1]):
        # 计算决策粗糙度
        U = np.max(class_vector) - np.min(class_vector)
        V = np.zeros(int(U))
        for j in range(int(U)):
            V[j] = np.sum(class_vector == j+1)
        G0 = np.sum(V ** 2) / (U * np.sum(V))

        # 计算约简后的决策粗糙度
        T = np.copy(class_vector)
        T[feature_matrix.iloc[:, i] > threshold] = U + 1
        U1 = np.max(T) - np.min(T)
        V1 = np.zeros(int(U1))
        for j in range(int(U1)):
            V1[j] = np.sum(T == j+1)
        G1 = np.sum(V1 ** 2) / (U1 * np.sum(V1))

        # 计算属性的重要度
        imp[i] = W[i] * (G0 - G1) / G0

    # 确定重要属性集
    red = []
    while True:
        if np.max(imp) <= 0:
            break
        max_idx = np.argmax(imp)
        red.append(max_idx)
        imp[max_idx] = 0
        for i in range(feature_matrix.shape[1]):
            if imp[i] > 0:
                imp[i] = imp[i] - W[i] * np.exp(-np.sum(np.abs(feature_matrix.iloc[:, max_idx] - feature_matrix.iloc[:, i])) / feature_matrix.shape[0])

    return red

def fuzzy_quick_reduct3(X, y, alpha):
    """
    Fuzzy QuickReduct算法，用于属性约简

    参数：
    X -- 特征矩阵，numpy数组类型，大小为(n_samples, n_features)
    y -- 类别向量，numpy数组类型，大小为(n_samples,)
    alpha -- 阈值参数，取值范围为[0,1]

    返回值：
    reduct -- 属性约简结果，即保留的特征子集的下标
    """
    n_samples, n_features = X.shape
    S = [set([i]) for i in range(n_features)]
    C = np.unique(y)
    F = np.zeros((n_samples, len(C), n_features))
    y=y.values
    for i in range(n_samples):
        for j in range(len(C)):
            for k in range(n_features):
                if y[i] == C[j]:
                    F[i][j][k] = X.iloc[i,k]
                else:
                    F[i][j][k] = 1 - X.iloc[i,k]

    FS = np.zeros((n_samples, len(S)))
    for i in range(n_samples):
        for j in range(len(S)):
            s = list(S[j])
            FS[i][j] = min([max(F[i][k][s]) for k in range(len(C))])

    D = np.zeros((n_samples, len(S)))
    for i in range(n_samples):
        for j in range(len(S)):
            if FS[i][j] >= alpha:
                D[i][j] = 1

    reduct = set(range(n_features))
    while True:
        remove_list = []
        for i in range(len(S)):
            if i in reduct and set(S[i]).issubset(reduct - set([i])):
                reduct.remove(i)
                remove_list.append(i)

        if not remove_list:
            break

        remove_list.reverse()
        for i in remove_list:
            del S[i]
            FS = np.delete(FS, i, axis=1)
            D = np.delete(D, i, axis=1)

    return reduct

def fuzzy_quick_reduct4(X, Y, w):
    Y=Y.values
    n, m = X.shape
    D = np.zeros((n, n))
    for i in range(n):
        for j in range(i+1, n):
            D[i][j] = np.sum(np.abs(X.iloc[:,i]-X.iloc[:,j])**w)
            D[j][i] = D[i][j]

    S = np.zeros(m)
    for i in range(m):
        S[i] = np.sum(np.abs(X.iloc[:,i])**w)

    U = np.ones(m)
    for i in range(m):
        for j in range(m):
            if i != j:
                U[i] = U[i] * ((np.sum(np.abs(X.iloc[:, i]-X.iloc[:, j])**w) / (n**2)) ** (1/w))

    V = np.zeros(m)
    for i in range(m):
        V[i] = S[i] * U[i]

    pos = np.arange(m)
    idx = np.argsort(V)
    P = []
    for i in range(m):
        j = idx[i]
        if np.all(Y == Y[0]):
            break
        if j in pos:
            P.append(j)
            pos = np.setdiff1d(pos, j)
            if np.all(pos.size == 0):
                break
    return P

def fuzzy_quick_reduct5(X,y, threshold):
    """
    :param df: 数据集，DataFrame格式
    :param threshold: 粗糙集约简阈值
    :return: 约简后的属性集合
    """
    # Step 1: 初始化模糊粗糙集
    U = X.values  # 特征矩阵
    C = y.values # 类别向量
    N, D = U.shape  # 样本数量，属性数量

    # Step 2: 计算属性的模糊决策矩阵
    fuzzy_decision_matrix = np.zeros((N, D))
    for j in range(D):
        max_val = np.max(U[:, j])
        min_val = np.min(U[:, j])
        if max_val == min_val:
            fuzzy_decision_matrix[:, j] = np.where(U[:, j] == max_val, 1, 0)
        else:
            fuzzy_decision_matrix[:, j] = (U[:, j] - min_val) / (max_val - min_val)

    # Step 3: 计算属性的模糊熵
    fuzzy_entropy = np.zeros(D)
    for j in range(D):
        fuzzy_entropy[j] = -np.sum(fuzzy_decision_matrix[:, j] * np.log2(fuzzy_decision_matrix[:, j]))

    # Step 4: 粗糙集约简
    reduct = []  # 约简后的属性集合
    while True:
        if len(reduct) == 0:
            S = np.arange(D)
        else:
            S = np.array(reduct)
        C_S = np.unique(C)  # 类别集合
        R = np.zeros((len(C_S), len(S)))  # 决策矩阵
        for i in range(len(C_S)):
            for j in range(len(S)):
                idx = np.logical_and(C == C_S[i], fuzzy_decision_matrix[:, S[j]] >= threshold)
                R[i, j] = np.sum(idx) / np.sum(C == C_S[i])
        S_entropy = np.zeros(len(S))  # 子集模糊熵
        for j in range(len(S)):
            S_entropy[j] = -np.sum(fuzzy_decision_matrix[:, S[j]] * np.log2(fuzzy_decision_matrix[:, j]))
        delta = np.zeros(len(S))  # 贡献度
        for j in range(len(S)):
            delta[j] = fuzzy_entropy[S[j]] - S_entropy[j]
        if np.all(delta <= 0):
            break
        max_idx = np.argmax(delta)
        reduct.append(S[max_idx])

    return reduct

def fuzzy_membership(x, c, delta):
    """计算元素x在模糊概念c中的隶属度"""
    if x < c - delta:
        return 0
    elif x > c + delta:
        return 1
    else:
        return (x - c + delta) / (2 * delta)

def calculate_membership_matrix(df, delta):
    """计算模糊概念下所有元素的隶属度矩阵"""
    n_rows, n_cols = df.shape
    membership_matrix = np.zeros((n_rows, n_cols))
    for j in range(n_cols):
        col = df.iloc[:, j].values
        for i in range(n_rows):
            membership_matrix[i][j] = fuzzy_membership(col[i], col.mean(), delta)
    return membership_matrix

def calculate_lower_approximation(membership_matrix, category_vector):
    """计算决策属性下粗糙集的下近似近似集合"""
    lower_approximation = []
    for i in range(len(category_vector)):
        if category_vector[i] == 1:
            lower_approximation.append(i)
    lower_approximation_set = set(lower_approximation)
    for i in range(membership_matrix.shape[1]):
        column = membership_matrix[:, i]
        subset = set(np.where(column > 0)[0])
        if lower_approximation_set.issuperset(subset):
            lower_approximation_set = subset
    return list(lower_approximation_set)

def calculate_dependency(membership_matrix, category_vector, feature_indices):
    """计算属性子集feature_indices的依赖度"""
    n_rows, n_cols = membership_matrix.shape
    reduced_df = membership_matrix[:, list(feature_indices)]
    subset = set(feature_indices)
    for j in range(n_cols):
        if j not in subset:
            col = membership_matrix[:, j]
            subset &= set(np.where(col > 0)[0])
    subset = list(subset)
    reduced_df = reduced_df[:,subset]
    lower_approximation_set = calculate_lower_approximation(reduced_df, category_vector)
    return len(lower_approximation_set) / n_rows

def fuzzy_quick_reduct6(df, y, delta):
    """模糊粗糙集属性约简"""
    normalized_df = df
    category_vector=y.values
    membership_matrix = calculate_membership_matrix(normalized_df, delta)
    feature_indices = set(range(df.shape[1]))
    for i in range(df.shape[1]):
        if i in feature_indices:
            temp_indices = feature_indices - set([i])
            dep1 = calculate_dependency(membership_matrix, category_vector, feature_indices)
            dep2 = calculate_dependency(membership_matrix, category_vector, temp_indices)
            if dep1 <= dep2:
                feature_indices = temp_indices
    return df.iloc[:, list(feature_indices)]

def fuzzy_quick_reduct7(data, class_col, alpha):
    """
    data: 数据框，最后一列为类别列
    class_col: 类别列的名称或索引
    alpha: 模糊参数
    """

    # 1. 初始化
    # 前提条件是：data已经按类别列排序好
    cols = data.columns.drop(class_col)
    U = data.values[:, :-1]
    V = data[class_col].values
    n = len(cols)
    reduct = set()
    sig = [0] * n

    # 2. 求属性的正域与决策域
    pos = []
    dec = []
    for i in range(n):
        pos_i = np.where(V == 1)[0] if np.var(U[:, i]) == 0 else np.where(U[:, i] >= np.percentile(U[:, i], (1 - alpha) * 100)) [0]
        dec_i = np.unique(V[pos_i])
        pos.append(pos_i)
        dec.append(dec_i)

    # 3. 进行属性约简
    while True:
        max_sig = 0
        max_sig_idx = None
        for i in range(n):
            if i not in reduct:
                # 3.1 计算sigma
                pos_i = pos[i]
                dec_i = dec[i]
                sig_i = 0
                for d in dec_i:
                    idx_d = np.where(V == d)[0]
                    pos_i_d = np.intersect1d(pos_i, idx_d)
                    sig_i += (len(pos_i_d) / len(pos_i)) ** 2
                sig_i *= len(pos_i) / len(U)

                # 3.2 更新max_sig
                if sig_i > max_sig:
                    max_sig = sig_i
                    max_sig_idx = i

        # 3.3 判断是否结束
        if max_sig == 0:
            break

        # 3.4 将max_sig_idx加入约简结果中
        reduct.add(max_sig_idx)
        sig[max_sig_idx] = max_sig

    return list(cols[list(reduct)])

def fuzzy_quick_reduct8(df, alpha=0.5):
    """
    FuzzyQuickReduct算法实现

    参数：
    df: DataFrame，包含数据集的特征和标签
    alpha: float，[0, 1]之间的模糊因子，默认为0.5

    返回：
    reduct_cols: list，特征约简后的列名列表
    """
    # 将df中的标签列提取出来
    label_col = df.columns[-1]
    # 计算每个特征的熵
    entropies = []
    for col in df.columns[:-1]:
        counts = df.groupby(col)[label_col].value_counts()
        freqs = counts / counts.sum()
        entropy = -freqs.mul(np.log2(freqs)).groupby(level=0).sum()
        entropies.append(entropy)
    entropies = pd.Series(entropies, index=df.columns[:-1])
    # 对特征按熵从小到大排序
    sorted_cols = entropies.sort_values().index.tolist()
    # 计算每个特征与其他特征的相似度
    similarities = []
    for i in range(len(sorted_cols)-1):
        sim = []
        for j in range(i+1, len(sorted_cols)):
            x = df[[sorted_cols[i], sorted_cols[j], label_col]]
            sim_ij = x.groupby([sorted_cols[i], sorted_cols[j]])[label_col].apply(lambda x: x.value_counts(normalize=True).values).values
            sim_ij = sim_ij.mean(axis=0)
            sim.append(sim_ij)
        similarities.append(sim)
    # 计算每个特征的关联度
    relevances = []
    for i in range(len(sorted_cols)):
        relevance = 0
        for j in range(len(similarities)):
            if i <= j:
                break
            relevance += np.max(similarities[j][i-1])
        relevances.append(relevance)
    relevances = pd.Series(relevances, index=sorted_cols)
    # 对特征按关联度从大到小排序
    sorted_cols = relevances.sort_values(ascending=False).index.tolist()
    # 对特征进行约简
    reduct_cols = [sorted_cols[0]]
    for i in range(1, len(sorted_cols)):
        x = df[reduct_cols+[sorted_cols[i], label_col]]
        sim = x.groupby(reduct_cols)[sorted_cols[i]].apply(lambda x: x.value_counts(normalize=True).values).values
        sim = sim.mean(axis=0)
        if np.max(sim) >= alpha:
            continue
        reduct_cols.append(sorted_cols[i])
    return reduct_cols

def fuzzy_quick_reduct9(X, Y, gamma):
    m, n = X.shape
    X=X.values
    Y=Y.values
    C = np.unique(Y)
    U = np.zeros((m, len(C)))
    for i in range(m):
        for j in range(len(C)):
            U[i][j] = 1 if Y[i] == C[j] else 0
    U_bar = np.power(U, gamma)
    R = list(range(n))
    while True:
        if len(R) == 1:
            break
        W = np.zeros((n, n))
        for i in range(n):
            for j in range(i+1, n):
                W[i][j] = 1 - (np.sum(np.minimum(U_bar[:, i], U_bar[:, j])) / np.sum(np.maximum(U_bar[:, i], U_bar[:, j])))
        max_w = np.max(W)
        if max_w == 0:
            break
        R.remove(np.argmax(np.max(W, axis=0)))
        U_bar = np.power(U[:, R], gamma)
    return R

def fuzzy_quick_reduct10(X, Y, thresh):
    '''
    基于模糊粗糙集的 FuzzyQuickReduct 算法

    参数：
    X: 特征矩阵，大小为(m, n)，其中m是样本数，n是特征数
    Y: 类别向量，大小为(m,)，取值为0或1
    thresh: 阈值参数，取值范围为[0, 1]

    返回：
    reduced_idx: 约简后的特征下标
    '''
    X=X.values
    Y=Y.values
    m, n = X.shape

    # 计算每个特征的区间和模糊粗糙值
    intervals = []
    values = []
    for j in range(n):
        column = X[:, j]
        column_min = np.min(column)
        column_max = np.max(column)
        interval = column_max - column_min
        intervals.append(interval)

        if interval == 0:
            value = 1
        else:
            normalized = (column - column_min) / interval
            value = 1 - (np.abs(normalized - 0.5) / thresh)**2
        values.append(value)

    # 计算每个特征与类别之间的关联值
    relation = np.zeros((n,))
    for j in range(n):
        d = {}
        for i in range(m):
            if X[i, j] not in d:
                d[X[i, j]] = [0, 0]  # 计数器，第一个元素表示Y=0的个数，第二个元素表示Y=1的个数
            if Y[i] == 0:
                d[X[i, j]][0] += 1
            else:
                d[X[i, j]][1] += 1
        value = 0
        for cnt in d.values():
            if cnt[0] == 0 or cnt[1] == 0:
                continue
            value += (cnt[0] + cnt[1]) / m * (1 - (cnt[0] / (cnt[0] + cnt[1]))**2 - (cnt[1] / (cnt[0] + cnt[1]))**2)
        relation[j] = value

    # 对每个特征进行排序
    order = np.argsort(-np.array(relation))
    selected = [order[0]]

    # 逐个加入特征
    for i in range(1, n):
        print(i)
        selected.append(order[i])
        A = X[:, selected]
        Temp = np.array(values)[selected]
        B=Temp[0]
        for index in range(1,Temp.shape[0]):
            print('index:',index)
            B=np.column_stack([B,Temp[index]])
        U = np.min(A, axis=1)
        L = np.max(np.minimum(A, B), axis=1)
        roughness = np.sum(Y != (L <= U))
        if roughness == 0:
            return selected

    return selected[:-1]

def fuzzy_quick_reduct11(X, Y, delta):
    """
    基于模糊粗糙集的 FuzzyQuickReduct 算法

    :param X: 特征矩阵，每一行表示一个数据实例，每一列表示一个特征
    :param Y: 类别向量，长度与 X 的行数相同，每个元素表示相应数据实例的类别
    :param delta: 模糊参数，控制属性的重要性权重，取值范围为 [0, 1]
    :return: 一个布尔型列表，表示是否选取对应特征作为属性子集中的一员
    """
    X=X.values
    Y=Y.values
    def positive_region(U):
        """
        模糊粗糙集的正域

        :param U: 所有数据实例的隶属度矩阵
        :return: 正域，即所有 U(i) 非空的数据实例的下标
        """
        return np.nonzero(np.sum(U, axis=1) > 0)[0]

    def reduct(C, U):
        """
        计算属性约简

        :param C: 当前属性集合，为布尔型列表，表示是否选取对应特征作为属性子集中的一员
        :param U: 所有数据实例的隶属度矩阵
        :return: 约简后的属性集合
        """
        m = U.shape[1]
        while True:
            # 步骤1：计算正域
            pos = positive_region(U[:, C])
            # 步骤2：计算增量
            inc = np.zeros(m)
            for i in range(m):
                if not C[i]:
                    inc[i] = len(positive_region(np.minimum(U[:, C + [i]], U[:, pos])))
            # 步骤3：选取增量最大的属性
            idx = np.argmax(inc)
            if inc[idx] == 0:
                break
            C[idx] = True
        return C

    # 步骤1：计算隶属度矩阵
    n = X.shape[0]
    U = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            if Y[i] == Y[j]:
                U[i, j] = U[j, i] = 1
            else:
                U[i, j] = U[j, i] = delta
    # 步骤2：属性约简
    C = [True] * X.shape[1]
    return reduct(C, U)

def get_similarity(x, y, fuzzy_parameter):
    """
    计算两个样本的相似度
    :param x: 第一个样本，为一个向量
    :param y: 第二个样本，为一个向量
    :param fuzzy_parameter: 模糊参数，用于计算模糊相似度，默认值为 1.0
    :return: 两个样本的相似度
    """
    numerator = np.sum(np.minimum(x, y) ** fuzzy_parameter)
    denominator = np.sum(np.maximum(x, y) ** fuzzy_parameter)
    similarity = numerator / denominator
    return similarity

def fuzzy_quick_reduct12(X, y, fuzzy_parameter=1.0):
    """
    模糊粗糙集属性约简算法 FuzzyQuickReduct
    :param X: 特征矩阵，为一个 m*n 的二维数组，每行代表一个样本，每列代表一个特征
    :param y: 类别向量，为一个 m*1 的一维数组，每个元素代表一个样本的类别
    :param fuzzy_parameter: 模糊参数，用于计算模糊相似度，默认值为 1.0
    :return: 一个列表，包含被约简后的特征的下标
    """
    X=X.values
    y=y.values
    # Step 1: 计算初始特征的重要度
    feature_importance = np.zeros(X.shape[1])
    for i in range(X.shape[1]):
        for j in range(X.shape[1]):
            if i != j:
                sim = get_similarity(X[:, i], X[:, j], fuzzy_parameter)
                feature_importance[i] += sim
    # Step 2: 特征重要度排序，得到初始的约简结果
    feature_ranking = np.argsort(feature_importance)[::-1]
    reduct = [feature_ranking[0]]
    # Step 3: 迭代求解最小约简结果
    for i in range(1, len(feature_ranking)):
        temp_reduct = reduct + [feature_ranking[i]]
        X_temp = X[:, temp_reduct]
        print(i)
        sim = get_similarity(X[:, reduct], X_temp, fuzzy_parameter)
        if sim < 1:
            reduct.append(feature_ranking[i])
    return reduct

def fuzzy_quick_reduct13(df, c, fuzzy_factor=0.5):
    """
    基于模糊粗糙集的FuzzyQuickReduct属性约简算法
    :param df: 数据集，包含m个样本，n个特征和1个类别
    :param c: 类别所在的列索引
    :param fuzzy_factor: 模糊因子，默认为0.5
    :return: 特征子集（即约简结果），包含被选择的特征列的索引
    """
    # 数据预处理
    x=df.iloc[:,:-1]
    y = df[c]
    # 计算粗糙熵
    num_samples = len(df)
    c_ent = - sum((y.value_counts() / num_samples) * np.log2(y.value_counts() / num_samples))
    # 初始化特征权重矩阵
    m, n = x.shape
    weight_matrix = np.zeros((n, n))
    # 计算特征权重矩阵
    for i in range(n):
        for j in range(n):
            if i != j:
                xi = x.iloc[:, i]
                xj = x.iloc[:, j]
                for k in range(n):
                    if k != i and k != j:
                        xk = x.iloc[:, k]
                        n0 = ((xi <= xj) & (xj <= xk) & (xj - xi >= fuzzy_factor * (xi - xk)) &
                              (xk - xj >= fuzzy_factor * (xi - xk))).sum()
                        n1 = ((xi >= xj) & (xj >= xk) & (xi - xj >= fuzzy_factor * (xk - xi)) &
                              (xj - xk >= fuzzy_factor * (xk - xi))).sum()
                        w = (n0 + n1) / num_samples
                        weight_matrix[i, j] += w
    # 特征选择
    f = set(range(n))
    sf = set()
    while True:
        max_weight_sum = -1
        max_feature = None
        for i in f:
            weight_sum = 0
            for j in sf:
                weight_sum += weight_matrix[i, j]
            if weight_sum > max_weight_sum:
                max_weight_sum = weight_sum
                max_feature = i
        if max_feature is None:
            break
        sf.add(max_feature)
        f.remove(max_feature)
    # 返回特征子集（即约简结果），包含被选择的特征列的索引
    return list(sf)

def fuzzy_quick_reduct14(X,y, alpha=0.5):
    """
    基于模糊粗糙集的 FuzzyQuickReduct 属性约简算法
    :param data: DataFrame类型，数据集
    :param alpha: 模糊参数
    :return: 属性约简结果列表
    """
    # 将数据集分为特征矩阵和类别向量
    X = X.values
    y = y.values

    # 最小-最大归一化对特征矩阵进行预处理
    X_normalized = X

    # 初始化属性约简结果列表
    reduct = []

    # 对每一个特征列进行处理
    for i in range(X_normalized.shape[1]):
        # 当前特征列
        A = X_normalized[:, i]
        # 初始化关联矩阵
        R = np.zeros((A.shape[0], A.shape[0]))
        for j in range(A.shape[0]):
            for k in range(j+1, A.shape[0]):
                # 计算关联矩阵中第j行第k列的值
                R[j][k] = R[k][j] = np.exp(-alpha * (A[j] - A[k]) ** 2)

        # 计算关联矩阵每一行的和，用于计算约简度
        row_sum = np.sum(R, axis=1)
        # 计算当前属性的约简度
        red = np.sum(row_sum / A.shape[0])
        # 将当前属性加入属性约简结果列表
        reduct.append((i, red))

    # 按照属性的约简度从大到小排序
    reduct = sorted(reduct, key=lambda x: x[1], reverse=True)

    # 将属性约简结果列表转换成只包含属性序号的列表
    reduct = [x[0] for x in reduct]

    return reduct

def fuzzy_rough_attribute_reduction(data, labels, threshold=0.1):
    """
    模糊粗糙集属性约简算法

    参数:
    data: numpy.array, shape=(n_samples, n_features)
        原始数据集的特征矩阵
    labels: numpy.array, shape=(n_samples,)
        原始数据集的标签向量
    threshold: float, optional (default=0.1)
        依赖度阈值，用于属性重要性排序和属性约简

    返回:
    selected_features: list
        约简后的属性子集
    """
    data=data.values
    labels=labels.values
    n_samples, n_features = data.shape
    dependency = np.zeros(n_features)  # 依赖度向量
    selected_features = list(range(n_features))  # 初始化属性子集为所有属性

    # 计算依赖度
    for i in range(n_features):
        A = data[:, i]  # 当前属性列
        for j in range(n_features):
            if j != i:
                B = data[:, j]  # 其他属性列
                AB = np.vstack((A, B))  # 构造属性对
                n_AB = np.min(AB, axis=0)  # 取最小值
                dep = np.sum(n_AB * (labels == labels.reshape(-1, 1))) / n_samples  # 计算依赖度
                dependency[i] += dep

    # 属性约简
    while True:
        max_dependency = np.max(dependency[selected_features])# 最大依赖度
        if (max_dependency <= threshold) or (len(selected_features)<=10):

            break  # 如果最大依赖度低于阈值或属性个数小于等于10个，则停止约简

        # 选择具有最大依赖度的属性
        max_dependency_indices = np.where(dependency == max_dependency)[0]
        selected_feature = max_dependency_indices[0]

        # 将选择的属性从属性子集中剔除
        selected_features.remove(selected_feature)

        # 更新依赖度
        for i in range(n_features):
            if i != selected_feature and i in selected_features:
                A = data[:, i]  # 当前属性列
                B = data[:, selected_feature]  # 选择的属性列
                AB = np.vstack((A, B))  # 构造属性对
                n_AB = np.min(AB, axis=0)  # 取最小值
                dep = np.sum(n_AB * (labels == labels.reshape(-1, 1))) / n_samples  # 计算依赖度
                dependency[i] -= dep
    return selected_features

def dependency_based_fuzzy_rough_set(data, k):
    # 计算属性之间的相关系数和不相关系数
    data=data.values()
    n = data.shape[1] - 1
    corr_pos = np.zeros((n, n))
    corr_neg = np.zeros((n, n))
    corr_0 = np.zeros((n, n))
    for i in range(n):
        for j in range(i+1, n):
            A = data[:, i]
            B = data[:, j]
            pos = np.sum((A == B) & (A != -1))
            neg = np.sum((A != B) & (A != -1))
            corr_pos[i, j] = corr_pos[j, i] = pos / np.sum(A != -1)
            corr_neg[i, j] = corr_neg[j, i] = neg / np.sum(A != -1)
            corr_0[i, j] = corr_0[j, i] = 1 - pos/neg if neg != 0 else 0

    # 计算属性的依赖度
    dep = np.zeros(n)
    for i in range(n):
        tmp = 0
        for j in range(n):
            if i != j:
                tmp += corr_pos[i, j] + corr_neg[i, j]
        dep[i] = tmp

    # 计算属性的不确定度
    unc = np.zeros(n)
    for i in range(n):
        tmp = 0
        for j in range(data.shape[0]):
            if data[j, i] == -1:
                continue
            c1 = np.sum(data[:, -1] == data[j, -1])
            c2 = np.sum((data[:, -1] != data[j, -1]) & (data[:, i] == data[j, i]))
            tmp += (c2 / c1) ** 2
        unc[i] = 1 - tmp / data.shape[0]

    # 计算属性的重要度
    imp = dep * unc

    # 对属性重要度进行排序，选择前k个属性作为约简属性集
    sorted_indices = np.argsort(-imp)
    selected_indices = sorted_indices[:k]
    selected_indices = np.append(selected_indices, n)
    return selected_indices

def fuzzy_rough_dependency_reduction(X, y, k):
    """
    基于依赖度的模糊粗糙集属性约简算法
    :param X: 数据集，二维数组形式，每一行表示一个样本，每一列表示一个属性
    :param y: 类标签，一维数组形式，每个元素表示一个样本的类别
    :param k: 约简得特征数
    :return: 约简得特征集合
    """
    X=X.values
    y=y.values
    n_samples, n_features = X.shape
    # 将类别变量编码为数值变量
    _, y_encoded = np.unique(y, return_inverse=True)
    # 计算每个属性之间的关联关系
    corr_matrix = np.corrcoef(X, rowvar=False)
    # 计算不确定度
    u = 1 - np.abs(corr_matrix)
    # 计算属性的依赖度
    dep = np.zeros(n_features)
    for i in range(n_features):
        for j in range(n_features):
            if i == j:
                continue
            if corr_matrix[i, j] >= 0:
                dep[i] += u[i, j]
    # 计算属性重要度
    imp = np.zeros(n_features)
    for i in range(n_features):
        imp[i] = dep[i] / np.sum(dep)
    # 将属性按照重要度从大到小排序
    sorted_idx = np.argsort(-imp)
    # 返回重要度排名前k的属性
    return sorted_idx[:k]
#
def dependency_coefficient(x, y):
    # 计算属性x和属性y之间的关联系数
    # 返回关联系数和反关联系数的最大值
    return max(
        np.sum(np.minimum(x, y)) / np.sum(np.maximum(x, y)),
        np.sum(np.minimum(1 - x, y)) / np.sum(np.maximum(1 - x, y)),
        np.sum(np.minimum(x, 1 - y)) / np.sum(np.maximum(x, 1 - y)),
        np.sum(np.minimum(1 - x, 1 - y)) / np.sum(np.maximum(1 - x, 1 - y))
    )

def dependency(x, y, z):
    # 计算属性x和属性y在属性z条件下的依赖度
    return np.sum(np.minimum(np.minimum(x, y), z)) / np.sum(z)

# def fuzzy_rough_set_reduction(data, num_feature):
#     data=data.values
#     n_features = data.shape[1] - 1
#     dep = np.zeros((n_features, n_features))
#
#     # 计算属性之间的关联系数和依赖度
#     for i in range(n_features):
#         for j in range(n_features):
#             dep[i][j] = dependency_coefficient(data[:, i], data[:, j])
#
#     for i in range(n_features):
#         for j in range(n_features):
#             for k in range(n_features):
#                 dep[i][j] = max(dep[i][j], dependency(data[:, i], data[:, j], data[:, k]))
#
#     # 计算属性的重要度
#     importance = np.zeros(n_features)
#     for i in range(n_features):
#         importance[i] = np.sum(dep[i, :]) + np.sum(dep[:, i])
#
#     # 将属性按照重要度排序
#     feature_indices = np.argsort(importance)[::-1]
#
#     # 选择前k个属性进行约简
#     selected_features = feature_indices[:num_feature]
#
#     return selected_features
#
# def fuzzy_rough_dependency_reduction(X, y, k):
#     # 计算属性之间的关联系数
#     X=X.values
#     y=y.values
#     corr_matrix = np.corrcoef(X.T)
#     corr_coefficients = np.abs(corr_matrix)  # 取绝对值，因为我们只关心关系的强弱
#
#     # 计算不确定度
#     N = X.shape[0]
#     mean_y = np.mean(y)
#     var_y = np.sum((y - mean_y) ** 2) / (N - 1)
#     delta_y = np.sqrt(var_y)
#     uncertainty = delta_y / (np.max(y) - np.min(y))  # 标准化不确定度
#
#     # 计算属性重要度
#     importance = np.zeros(X.shape[1])
#     for i in range(X.shape[1]):
#         pos_dependency = np.mean(corr_coefficients[i,:][y>=mean_y])
#         neg_dependency = np.mean(corr_coefficients[i,:][y<mean_y])
#         importance[i] = uncertainty - max(pos_dependency, neg_dependency)
#
#     # 按照属性重要度排序，选择前k个属性
#     selected_features = np.argsort(importance)[::-1][:k]
#
#     return selected_features

# #
# def calc_dependency(data, label, alpha):
#     """
#     计算依赖度
#     """
#     n, m = data.shape
#     D = np.zeros((m, m))
#
#     for i in range(m):
#         for j in range(m):
#             if i == j:
#                 continue
#             # 计算属性i和属性j之间的正关联系数
#             pos_corr = np.sum(np.logical_and(data[:, i] >= alpha, data[:, j] >= alpha) * label) / np.sum(data[:, i] >= alpha)
#             # 计算属性i和属性j之间的负关联系数
#             neg_corr = np.sum(np.logical_and(data[:, i] < alpha, data[:, j] < alpha) * label) / np.sum(data[:, i] < alpha)
#             # 计算属性i和属性j之间的不相关系数
#             un_corr = 1 - pos_corr - neg_corr
#             # 计算依赖度
#             D[i, j] = pos_corr - neg_corr
#
#     return D
#
# def calc_uncertainty(data, label):
#     """
#     计算不确定度
#     """
#     n, m = data.shape
#     U = np.zeros(m)
#
#     for i in range(m):
#         # 计算属性i的不确定度
#         p1 = np.sum(data[:, i] * label) / np.sum(data[:, i])
#         p2 = np.sum((1 - data[:, i]) * label) / np.sum(1 - data[:, i])
#         U[i] = 1 - max(p1, p2)
#
#     return U
#
# def fuzzy_rough_set_reduction(data, label, alpha, k):
#     """
#     基于依赖度的模糊粗糙集属性约简算法
#     """
#     data=data.values
#     label=label.values
#     n, m = data.shape
#
#     # 计算依赖度和不确定度
#     D = calc_dependency(data, label, alpha)
#     U = calc_uncertainty(data, label)
#
#     # 计算属性重要度
#     importance = np.zeros(m)
#     for i in range(m):
#         importance[i] = (1 - U[i]) * np.sum(np.abs(D[i, :])) / (m - 1)
#
#     # 按照属性重要度排序
#     indices = np.argsort(importance)[::-1]
#
#     # 选择前k个属性进行约简
#     selected = indices[:k]
#
#     return selected

#
# 计算属性a和b之间的关联系数
#####################################
def dep(a, b, D):
    n = D.shape[0]
    p1 = sum(D[:, a] * D[:, b]) / n
    p2 = sum(D[:, a]) / n
    p3 = sum(D[:, b]) / n
    return (p1 - p2 * p3) / (min(p2, p3) - p2 * p3)

# 计算属性a的不确定度
def ind(a, D):
    n = D.shape[0]
    p = sum(D[:, a]) / n
    return 2 * p * (1 - p)

# 计算属性a的相对重要度
def importance(a, D):
    return dep(a, -1, D) - ind(a, D)

# 基于依赖度的模糊粗糙集属性约简算法
def fuzzy_rough_set_reduction(D, k):
    D=D.values
    A = np.arange(D.shape[1] - 1)
    rank_list = sorted([(importance(a, D), a) for a in A], reverse=True)
    return [a[1] for a in rank_list[:k]]



ReadAddress=r"H:\PythonProject\MachineLearning\FoodSecurity\Data\ProcessingData\InitialData\InitialData_Normalized.xlsx"
fm=pd.read_excel(ReadAddress,sheet_name=None,index_col=0)
province='辽宁'
df=fm[province]
feathers=df.columns
X=df.iloc[1:,1:-1]
y=df['每亩主产品产量'][1:]

result=fuzzy_rough_set_reduction(X, y, 10)
print(result)
print(feathers[result])

# Temp=pd.concat([X,y],axis=1)
# print(Temp)
# result=fuzzy_rough_set_reduction(Temp, 10)
# print(result)
# print(feathers[result])

# 选合适的模糊参数
# Reducd=pd.DataFrame()
# for i in np.arange(0.01,0.9,0.02):
#     print('alpha=',i)
#     result=fuzzy_quick_reduct14(X, y, i)
#     selected_features=feathers[result]
#     print(selected_features)
#     print(result)
#     temp=pd.Series(result)
#     temp.rename(i,inplace=True)
#     # print(temp)
#     if i==0.01:
#         Reducd=temp.T
#     else:
#         Reducd=pd.concat([Reducd,temp.T],axis=1)
# Reducd=Reducd.T
# print(Reducd)
