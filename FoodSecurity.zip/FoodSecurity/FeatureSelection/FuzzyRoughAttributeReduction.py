import pandas as pd
import numpy as np
import os
import time
from timeit import default_timer as timer

def fuzzy_rough_attribute_reduction(data, labels, threshold,num_features):
    """
    模糊粗糙集属性约简算法

    参数:
    data: numpy.array, shape=(n_samples, n_features)
        原始数据集的特征矩阵
    labels: numpy.array, shape=(n_samples,)
        原始数据集的标签向量
    threshold: float, optional (default=0.1)
        依赖度阈值，用于属性重要性排序和属性约简

    返回:
    selected_features: list
        约简后的属性子集
    """
    data=data.values
    labels=labels.values
    n_samples, n_features = data.shape
    dependency = np.zeros(n_features)  # 依赖度向量
    selected_features = list(range(n_features))  # 初始化属性子集为所有属性

    # 计算依赖度
    for i in range(n_features):
        A = data[:, i]  # 当前属性列
        for j in range(n_features):
            if j != i:
                B = data[:, j]  # 其他属性列
                AB = np.vstack((A, B))  # 构造属性对
                n_AB = np.min(AB, axis=0)  # 取最小值
                dep = np.sum(n_AB * (labels == labels.reshape(-1, 1))) / n_samples  # 计算依赖度
                dependency[i] += dep

    # 属性约简
    while True:
        max_dependency = np.max(dependency[selected_features])# 最大依赖度
        if (max_dependency <= threshold) or (len(selected_features)<=num_features):

            break  # 如果最大依赖度低于阈值或属性个数小于等于10个，则停止约简

        # 选择具有最大依赖度的属性
        max_dependency_indices = np.where(dependency == max_dependency)[0]
        selected_feature = max_dependency_indices[0]

        # 将选择的属性从属性子集中剔除
        selected_features.remove(selected_feature)

        # 更新依赖度
        for i in range(n_features):
            if i != selected_feature and i in selected_features:
                A = data[:, i]  # 当前属性列
                B = data[:, selected_feature]  # 选择的属性列
                AB = np.vstack((A, B))  # 构造属性对
                n_AB = np.min(AB, axis=0)  # 取最小值
                dep = np.sum(n_AB * (labels == labels.reshape(-1, 1))) / n_samples  # 计算依赖度
                dependency[i] -= dep
    return selected_features

FileDirectory=os.getcwd()
ReadAddress=r"H:\PythonProject\MachineLearning\FoodSecurity\Data\ProcessingData\InitialData\InitialData_Normalized.xlsx"
ReadAddress2=r"H:\PythonProject\MachineLearning\FoodSecurity\Data\ProcessingData\InitialData\InitialData.xlsx"
WriteAddress=FileDirectory + r'\ReducedFeatures_FRAR.xlsx'
WriteAddress2=FileDirectory + r'\ReducedData_FRAR.xlsx'
WriteAddress3=FileDirectory + r'\RunningTime_FRAR.xlsx'
fm=pd.read_excel(ReadAddress,sheet_name=None,index_col=0)
fm2=pd.read_excel(ReadAddress2,sheet_name=None,index_col=0)
writer = pd.ExcelWriter(WriteAddress)
writer2 = pd.ExcelWriter(WriteAddress2)
writer3 = pd.ExcelWriter(WriteAddress3)
AllProvince=fm.keys()
ReducedFeatures=pd.DataFrame()
ConsumingTime=pd.Series()
for province in AllProvince:
    df=fm[province]
    print(province)
    X=df.iloc[1:,1:-1]
    y=df['每亩主产品产量'][1:]
    start_time = timer()
    num_features = 10
    result=fuzzy_rough_attribute_reduction(X, y, 0.1,num_features)
    end_time = timer()
    run_time=end_time-start_time
    ConsumingTime[province]=run_time
    top_features_idx = result[:num_features]
    top_features=X.columns[top_features_idx]
    Temp=pd.Series(top_features)
    Temp.rename(province,inplace=True)
    ReducedFeatures=pd.concat([ReducedFeatures,Temp],axis=1)
    df2=fm2[province]
    selected_data=df2.iloc[:,top_features_idx]
    selected_data=pd.concat([selected_data,df2['每亩主产品产量']],axis=1)
    selected_data=selected_data.iloc[1:,:]
    selected_data.to_excel(writer2,sheet_name=province)
    print("Top {} features: {}".format(num_features, X.columns[top_features_idx]))
writer2.save()
ColumnName = [f'feature {i}' for i in range(1, num_features+1)]
ReducedFeatures=ReducedFeatures.T
ReducedFeatures = ReducedFeatures.rename(columns=dict(zip(ReducedFeatures.columns, ColumnName)))
ReducedFeatures.to_excel(writer)
writer.save()
print(ConsumingTime)
ConsumingTime.rename('特征选择耗时',inplace=True)
ConsumingTime.to_excel(writer3,sheet_name='FuzzyRoughAttributeReduction')
writer3.save()
