import numpy as np

def fuzzy_similarity(a, b):
    """
    计算两个对象的模糊相似度
    使用欧氏距离作为度量方法
    """
    return np.linalg.norm(a - b)

def fuzzy_membership(data, equivalence_class):
    """
    计算模糊正域隶属度
    参数:
        - data: 数据集，每一行是一个对象的属性值
        - equivalence_class: 模糊等价类
    返回值:
        - membership: 模糊正域隶属度
    """
    n = len(data)  # 对象个数
    fuzzy_sum = 0.0
    for i in range(n):
        fuzzy_sum += fuzzy_similarity(data[i], equivalence_class)
    membership = fuzzy_sum / n
    return membership

def fuzzy_dependency(data, labels, equivalence_class):
    """
    计算模糊依赖度
    参数:
        - data: 数据集，每一行是一个对象的属性值
        - labels: 对象的标签值
        - equivalence_class: 模糊等价类
    返回值:
        - dependency: 模糊依赖度
    """
    membership = fuzzy_membership(data, equivalence_class)
    n = len(data)  # 对象个数
    fuzzy_sum = 0.0
    for i in range(n):
        if labels[i] >= membership:
            fuzzy_sum += 1.0
    dependency = fuzzy_sum / n
    return dependency

def construct_equivalence_class(data, labels):
    """
    构造模糊等价类
    参数:
        - data: 数据集，每一行是一个对象的属性值
        - labels: 对象的标签值
    返回值:
        - equivalence_class: 模糊等价类
    """
    n = len(data)  # 对象个数
    equivalence_class = np.zeros_like(data[0])  # 初始化等价类
    for i in range(n):
        equivalence_class += data[i] * labels[i]
    equivalence_class /= np.sum(labels)
    return equivalence_class

def attribute_reduction(data, labels):
    """
    使用模糊粗糙集属性约简算法进行属性约简
    参数:
        - data: 数据集，每一行是一个对象的属性值
        - labels: 对象的标签值
    返回值:
        - reduced_attributes: 约简后的属性索引列表
    """
    n = data.shape[1]  # 属性个数
    equivalence_class = construct_equivalence_class(data, labels)
    original_dependency = fuzzy_dependency(data, labels, equivalence_class)
    important_indices = list(range(n))  # 初始重要属性索引列表
    reduced_attributes = []  # 约简后的属性索引列表

    while len(important_indices) > 0:
        max_reduction = 0.0
        best_attribute = None
        for attr in important_indices:
            temp_data = np.delete(data, attr, axis=1)
            temp_equivalence_class = construct_equivalence_class(temp_data, labels)
            temp_dependency = fuzzy_dependency(temp_data, labels, temp_equivalence_class)
            reduction = original_dependency - temp_dependency
            if reduction > max_reduction:
                max_reduction = reduction
                best_attribute = attr
        if best_attribute is not None:
            important_indices.remove(best_attribute)
            reduced_attributes.append(best_attribute)
            original_dependency = original_dependency - max_reduction
        else:
            break

    return reduced_attributes

# 示例数据
data = np.array([[1, 2, 3],
                 [4, 5, 6],
                 [7, 8, 9]])
labels = np.array([0.3, 0.6, 0.9])

reduced_attributes = attribute_reduction(data, labels)
print("约简后的属性索引列表:", reduced_attributes)
