import numpy as np

def quick_reduce(X, y, thres=0.1):
    # X为特征矩阵，y为类别向量，thres为相关性阈值
    n_features = X.shape[1]
    corr_matrix = np.zeros((n_features, n_features))  # 初始化相关性矩阵

    # 计算模糊隶属度矩阵
    mu_matrix = np.zeros(X.shape)
    for i in range(n_features):
        for j in range(X.shape[0]):
            for k in range(X.shape[1]):
                if k == i:
                    mu_matrix[j, k] = 1  # 该属性在自己上的隶属度为1
                else:
                    mu_matrix[j, k] = calc_membership(X[j, i], X[:, k])

    # 计算粗糙度
    R = calc_roughness(mu_matrix, y)

    # 初始化属性约简为空集
    red_features = []

    # 遍历每个属性
    for i in range(n_features):
        if i not in red_features:
            # 添加当前属性到属性约简中
            red_features.append(i)

            # 计算其他属性与当前属性的相关性
            for j in range(n_features):
                if j == i or j in red_features:
                    continue
                corr_matrix[i, j] = calc_corr(mu_matrix[:, i], mu_matrix[:, j])

            # 根据相关性大小排序，将相关性大于阈值的属性剔除
            for j in range(n_features):
                if j == i or j in red_features:
                    continue
                if corr_matrix[i, j] >= thres:
                    red_features.remove(j)
    return red_features


# 计算两个属性之间的相关性
def calc_corr(mu1, mu2):
    corr = np.abs(np.corrcoef(mu1, mu2)[0, 1])
    return corr


# 计算属性在数据集上的隶属度
def calc_membership(x, X):
    min_val, max_val = np.min(X), np.max(X)
    if x <= min_val:
        return 0
    elif x >= max_val:
        return 1
    else:
        return (x - min_val) / (max_val - min_val)


# 计算粗糙度
def calc_roughness(mu_matrix, y):
    n_classes = len(np.unique(y))
    n_samples = mu_matrix.shape[0]
    R = np.zeros(n_samples)
    for i in range(n_samples):
        ind = np.where(mu_matrix[i, :] == 1)[0]  # 该样本在哪些类别中隶属度为1
        if len(ind) == 1:
            R[i] = 0  # 该样本的粗糙度为0，属于确定类别
        else:
            R[i] = 1 - np.max([np.sum(y == j) / len(y) for j in ind])
    return np.mean(R)


