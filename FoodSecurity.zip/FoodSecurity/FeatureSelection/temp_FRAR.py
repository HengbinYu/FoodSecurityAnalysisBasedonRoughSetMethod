import numpy as np
import pandas as pd
import os

import numpy as np
from scipy.spatial.distance import pdist, squareform
# FRAR1   利用信息增益计算属性重要性，利用欧几里得距离计算模糊相似性，
# def calculate_importance(data, labels):
#     num_attributes = data.shape[1]
#     importance = np.zeros(num_attributes)
#
#     # 计算每个属性的信息增益
#     for i in range(num_attributes):
#         # 获取当前属性的取值范围
#         min_val = np.min(data[:, i])
#         max_val = np.max(data[:, i])
#
#         # 将当前属性的取值范围划分为10个区间
#         intervals = np.linspace(min_val, max_val, 10)
#
#         # 计算每个区间的频率分布
#         hist, _ = np.histogram(data[:, i], bins=intervals)
#
#         # 计算每个区间的标签频率分布
#         label_hist, _ = np.histogram(data[:, i], bins=intervals, weights=labels)
#
#         # 计算属性的信息增益
#         total_entropy = entropy(labels)
#         attribute_entropy = 0
#         for j in range(len(hist)):
#             if hist[j] != 0:
#                 probability = hist[j] / np.sum(hist)
#                 attribute_entropy += probability * entropy(label_hist[j] / hist[j])
#
#         importance[i] = total_entropy - attribute_entropy
#
#     return importance
#
# def entropy(probability):
#     probability = np.clip(probability, 1e-15, 1)  # 避免概率为0的情况
#     return -np.sum(probability * np.log2(probability))
#
# def fuzzy_similarity(data):
#     distance_matrix = squareform(pdist(data, 'euclidean'))
#     similarity_matrix = 1 / (1 + distance_matrix)  # 使用Euclidean距离计算相似性
#     np.fill_diagonal(similarity_matrix, 1)  # 将对角线元素设置为1
#     return similarity_matrix
#
# def FRAR1(data, labels, threshold):
#     num_attributes = data.shape[1]
#     selected_attributes = list(range(num_attributes))  # 初始时选择所有属性
#     importance = calculate_importance(data, labels)
#     similarity_matrix = fuzzy_similarity(data)
#
#     while True:
#         candidate_scores = []
#         for attribute in selected_attributes:
#             # 计算当前属性与已选择属性之间的相似性得分
#             score = np.mean(similarity_matrix[:, attribute])
#             candidate_scores.append(score)
#
#         max_score = max(candidate_scores)
#         max_index = candidate_scores.index(max_score)
#         max_attribute = selected_attributes[max_index]
#
#         # 从选择的属性中移除得分最高的属性
#         selected_attributes.remove(max_attribute)
#
#         # 判断是否存在子集与当前选择的属性集的相似性得分相等
#         redundant_attributes = []
#         for attribute in selected_attributes:
#             if np.mean(similarity_matrix[:, attribute]) == max_score:
#                 redundant_attributes.append(attribute)
#
#         # 从选择的属性中移除所有与最高得分属性相似性得分相等的属性
#         for attribute in redundant_attributes:
#             selected_attributes.remove(attribute)
#
#         if len(redundant_attributes) == 0 or max_score < threshold:
#             break
#
#     return selected_attributes
#
#
# # FRAR2：利用欧氏距离和信息熵来计算
# def attribute_importance(data, labels):
#     # 计算属性重要度，这里使用信息增益作为衡量标准
#     num_samples = len(labels)
#     num_attributes = data.shape[1]
#     label_entropy = entropy(labels)
#
#     importance = []
#     for attribute in range(num_attributes):
#         attribute_values = data[:, attribute]
#         attribute_entropy = 0.0
#
#         unique_values = np.unique(attribute_values)
#         for value in unique_values:
#             value_indices = np.where(attribute_values == value)[0]
#             value_labels = labels[value_indices]
#             value_entropy = entropy(value_labels)
#             value_weight = len(value_indices) / num_samples
#             attribute_entropy += value_weight * value_entropy
#
#         attribute_importance = label_entropy - attribute_entropy
#         importance.append(attribute_importance)
#
#     return importance
#
# def entropy(labels):
#     # 计算熵
#     unique_labels, label_counts = np.unique(labels, return_counts=True)
#     probabilities = label_counts / len(labels)
#     entropy = -np.sum(probabilities * np.log2(probabilities))
#     return entropy
#
# def fuzzy_similarity(data):
#     # 构建模糊相似关系矩阵
#     num_samples = data.shape[0]
#     similarity_matrix = np.zeros((num_samples, num_samples))
#
#     for i in range(num_samples):
#         for j in range(i + 1, num_samples):
#             similarity = np.exp(-np.linalg.norm(data[i] - data[j]))
#             similarity_matrix[i, j] = similarity
#             similarity_matrix[j, i] = similarity
#
#     return similarity_matrix
#
# def FRAR2(data, labels, threshold):
#     attribute_scores = attribute_importance(data, labels)
#     selected_attributes = []
#     num_attributes = len(attribute_scores)
#
#     similarity_matrix = fuzzy_similarity(data)
#
#     for i in range(num_attributes):
#         if attribute_scores[i] >= threshold:
#             selected_attributes.append(i)
#
#     reduct = selected_attributes.copy()
#
#     while True:
#         redundant_attributes = []
#         for attribute in reduct:
#             subset = reduct.copy()
#             subset.remove(attribute)
#             subset_matrix = similarity_matrix[np.ix_(subset, subset)]
#             subset_threshold = np.mean(subset_matrix)
#
#             if np.all(subset_matrix >= subset_threshold):
#                 redundant_attributes.append(attribute)
#
#         if len(redundant_attributes) == 0:
#             break
#
#         reduct = [attribute for attribute in reduct if attribute not in redundant_attributes]
#
#     return reduct
#
#
# # FRAR3：利用欧氏距离和相关系数
# # 计算属性重要度
# def calculate_attribute_importance(data, labels):
#     n_samples, n_attributes = data.shape
#     importance = np.zeros(n_attributes)
#     labels = labels.astype('float')
#     for i in range(n_attributes):
#         attribute_data = data[:, i]
#         attribute_data = attribute_data.astype('float')
#         importance[i] = np.corrcoef(attribute_data, labels)[0, 1]
#
#     return importance
#
# # 计算模糊相似关系矩阵
# def calculate_similarity_matrix(data):
#     n_samples, n_attributes = data.shape
#     similarity_matrix = np.zeros((n_samples, n_samples))
#
#     for i in range(n_samples):
#         for j in range(i, n_samples):
#             similarity_matrix[i, j] = similarity_matrix[j, i] = np.linalg.norm(data[i] - data[j])
#
#     return similarity_matrix
#
# # 模糊粗糙集属性约简算法
# def FRAR3(data, labels, threshold):
#     n_samples, n_attributes = data.shape
#     attribute_importance = calculate_attribute_importance(data, labels)
#     similarity_matrix = calculate_similarity_matrix(data)
#
#     # 初始化属性约简集为空
#     reduction_set = []
#
#     for i in range(n_attributes):
#         # 检查属性是否已被约简
#         if i in reduction_set:
#             continue
#
#         # 计算属性 i 与其他属性之间的相似度
#         similarity_sum = np.zeros(n_attributes)
#         for j in range(n_attributes):
#             if j != i and j not in reduction_set:
#                 similarity_sum[j] = np.sum(similarity_matrix[:, i] <= threshold) / n_samples
#
#         # 判断属性 i 是否重要
#         if attribute_importance[i] >= np.max(attribute_importance * similarity_sum):
#             # 将属性 i 加入约简集
#             reduction_set.append(i)
#
#     return reduction_set
#
#
# # FRAR4：相关系数计算属性重要度，模糊相似关系用欧氏距离的指数函数计算
# import math
# def calculate_correlation(X, y):
#     # 计算属性与标签之间的相关性
#     n = X.shape[0]
#     attribute_correlation = np.zeros(X.shape[1])
#     y=y.astype('float')
#     for i in range(X.shape[1]):
#         attribute = X[:, i]
#         attribute = attribute.astype('float')
#         covariance = np.cov(attribute, y)[0][1]
#         attribute_std = np.std(attribute)
#         label_std = np.std(y)
#
#         if attribute_std != 0 and label_std != 0:
#             attribute_correlation[i] = abs(covariance / (attribute_std * label_std))
#
#     return attribute_correlation
#
# def construct_fuzzy_similarity(X):
#     # 构造模糊相似关系
#     n = X.shape[0]
#     fuzzy_similarity = np.zeros((n, n))
#
#     for i in range(n):
#         for j in range(i, n):
#             similarity = np.exp(-np.linalg.norm(X[i] - X[j]))
#             fuzzy_similarity[i][j] = similarity
#             fuzzy_similarity[j][i] = similarity
#
#     return fuzzy_similarity
#
# def FRAR4(X, y):
#     attribute_correlation = calculate_correlation(X, y)
#     sorted_indices = np.argsort(attribute_correlation)[::-1]  # 按重要度降序排列属性
#
#     n = X.shape[0]
#     selected_indices = [sorted_indices[0]]  # 最重要的属性先选入约简集合
#
#     for i in range(1, len(sorted_indices)):
#         candidate_indices = selected_indices + [sorted_indices[i]]  # 假设当前属性为候选属性
#
#         # 计算模糊粗糙集下近似粗糙度
#         fuzzy_similarity = construct_fuzzy_similarity(X[:, candidate_indices])
#         roughness = 0
#
#         for j in range(n):
#             for k in range(j, n):
#                 roughness += abs(y[j] - y[k]) * fuzzy_similarity[j][k]
#
#         if roughness < math.sqrt(n):  # 判断是否满足约简条件
#             selected_indices = candidate_indices
#
#     return selected_indices
#
#
# # FRAR5:
# def FRAR5(data, labels):
#     num_attributes = data.shape[1]
#     num_samples = data.shape[0]
#     importance_scores = np.zeros(num_attributes)
#
#     # 计算属性重要度
#     for i in range(num_attributes):
#         attribute_values = data[:, i]
#         importance_scores[i] = fuzzy_entropy(attribute_values, labels)
#
#     # 按照属性重要度降序排序
#     sorted_indices = np.argsort(importance_scores)[::-1]
#
#     # 属性约简
#     selected_attributes = []
#     for i in sorted_indices:
#         selected_attributes.append(i)
#         reduction_data = data[:, selected_attributes]
#         if is_consistent(reduction_data, labels):
#             return selected_attributes
#
#     return selected_attributes
#
# def fuzzy_entropy(attribute_values, labels):
#     unique_values = np.unique(attribute_values)
#     num_values = len(unique_values)
#     num_samples = len(labels)
#     membership_degrees = np.zeros(num_values)
#
#     # 计算每个值的隶属度
#     for i, value in enumerate(unique_values):
#         membership_degrees[i] = np.sum(labels[attribute_values == value]) / num_samples
#
#     # 计算模糊熵
#     entropy = -np.sum(membership_degrees * np.log2(membership_degrees))
#
#     return entropy
#
# def is_consistent(data, labels):
#     unique_labels = np.unique(labels)
#     num_labels = len(unique_labels)
#
#     for label in unique_labels:
#         label_indices = np.where(labels == label)[0]
#         label_data = data[label_indices]
#         unique_rows = np.unique(label_data, axis=0)
#         num_unique_rows = unique_rows.shape[0]
#
#         if num_unique_rows < num_labels:
#             return False
#
#     return True
#
#
# # FRAR6:相关系数作为属性重要度，模糊相似关系选择指数
# def compute_attribute_importance(data, labels):
#     n_samples, n_attributes = data.shape
#     attribute_importance = np.zeros(n_attributes)
#     labels=labels.astype('float')
#     for i in range(n_attributes):
#         attribute_values = data[:, i].astype('float')
#         correlation_matrix = np.corrcoef(attribute_values, labels)
#         attribute_importance[i] = np.abs(correlation_matrix[0, 1])
#
#     return attribute_importance
#
# def construct_fuzzy_similarity_matrix(data):
#     n_samples, n_attributes = data.shape
#     similarity_matrix = np.zeros((n_samples, n_samples))
#
#     for i in range(n_samples):
#         for j in range(i+1, n_samples):
#             similarity = np.exp(-np.sum(np.abs(data[i] - data[j])) / n_attributes)
#             similarity_matrix[i, j] = similarity
#             similarity_matrix[j, i] = similarity
#
#     return similarity_matrix
#
# def FRAR6(data, labels, threshold):
#     n_samples, n_attributes = data.shape
#     attribute_importance = compute_attribute_importance(data, labels)
#     sorted_indices = np.argsort(attribute_importance)[::-1]
#     reduced_data = data.copy()
#
#     for i in range(n_attributes):
#         if attribute_importance[sorted_indices[i]] < threshold:
#             reduced_data = np.delete(reduced_data, sorted_indices[i], axis=1)
#
#     return reduced_data
#
#
# # FRAR7：相关系数计算相似度，欧氏距离计算模糊相似关系
# def calculate_attribute_importance(data, labels):
#     # 计算属性重要度
#     num_attributes = data.shape[1]
#     importance = np.zeros(num_attributes)
#     labels=labels.astype('float')
#     # 计算属性与标签的相关性
#     for i in range(num_attributes):
#         attribute_values = data[:, i].astype('float')
#         correlation = np.corrcoef(attribute_values, labels)[0, 1]
#         importance[i] = abs(correlation)
#
#     # 归一化属性重要度
#     importance /= np.sum(importance)
#
#     return importance
#
# def construct_fuzzy_similarity(data):
#     # 构造模糊相似关系
#     num_instances = data.shape[0]
#     similarity = np.zeros((num_instances, num_instances))
#
#     # 使用欧氏距离计算相似度
#     for i in range(num_instances):
#         for j in range(i + 1, num_instances):
#             distance = np.linalg.norm(data[i] - data[j])
#             similarity[i, j] = similarity[j, i] = np.exp(-distance)
#
#     return similarity
#
# def FRAR7(data, labels, threshold):
#     # 属性约简算法
#     num_instances, num_attributes = data.shape
#
#     # 计算属性重要度
#     importance = calculate_attribute_importance(data, labels)
#
#     # 构造模糊相似关系
#     similarity = construct_fuzzy_similarity(data)
#
#     # 计算属性之间的相似度
#     attribute_similarity = np.zeros((num_attributes, num_attributes))
#     for i in range(num_attributes):
#         for j in range(i + 1, num_attributes):
#             attribute_similarity[i, j] = attribute_similarity[j, i] = np.sum(similarity[:, i] * similarity[:, j]) / num_instances
#
#     # 初始化属性约简
#     current_subset = set(range(num_attributes))
#     final_subset = set()
#
#     # 迭代属性约简过程
#     while len(current_subset) > 0:
#         max_reduction = -1
#         best_attribute = None
#
#         # 计算属性的约简贡献
#         for attribute in current_subset:
#             reduction = importance[attribute]
#             for selected_attribute in final_subset:
#                 reduction *= attribute_similarity[attribute, selected_attribute]
#
#             if reduction > max_reduction:
#                 max_reduction = reduction
#                 best_attribute = attribute
#
#         # 判断是否满足约简阈值
#         if max_reduction >= threshold:
#             current_subset.remove(best_attribute)
#             final_subset.add(best_attribute)
#         else:
#             break
#
#     return final_subset
#
# # FRAR8:相关系数计算属性重要度，
# def calculate_attribute_importance(data, labels):
#     num_attributes = data.shape[1]
#     attribute_importance = np.zeros(num_attributes)
#     labels=labels.astype('float')
#     for i in range(num_attributes):
#         attribute_values = data[:, i].astype('float')
#         attribute_importance[i] = np.corrcoef(attribute_values, labels)[0, 1]
#
#     return attribute_importance
#
# def construct_fuzzy_similarity(data):
#     num_instances = data.shape[0]
#     fuzzy_similarity = np.zeros((num_instances, num_instances))
#
#     for i in range(num_instances):
#         for j in range(num_instances):
#             fuzzy_similarity[i, j] = 1.0 - np.abs(data[i] - data[j]).sum() / data.shape[1]
#
#     return fuzzy_similarity
#
# def FRAR8(data, labels, threshold):
#     attribute_importance = abs(calculate_attribute_importance(data, labels))
#     num_attributes = data.shape[1]
#
#     selected_attributes = []
#     for i in range(num_attributes):
#         if attribute_importance[i] >= threshold:
#             selected_attributes.append(i)
#     print(attribute_importance)
#     return selected_attributes
#

# # FRAR9:相关系数计算属性重要度，
# def calculate_attribute_importance(data, labels):
#     num_attributes = len(data[0])
#     attribute_importance = np.zeros(num_attributes)
#
#     for i in range(num_attributes):
#         attribute_values = data[:, i]
#         attribute_range = np.max(attribute_values) - np.min(attribute_values)
#         attribute_importance[i] = np.sum(np.abs(labels - attribute_values)) / (len(data) * attribute_range)
#
#     return attribute_importance
#
# def calculate_fuzzy_similarity(data, attribute_importance):
#     num_instances = len(data)
#     fuzzy_similarity = np.zeros((num_instances, num_instances))
#
#     for i in range(num_instances):
#         for j in range(i, num_instances):
#             similarity = np.exp(-np.sum(np.abs(data[i] - data[j]) * attribute_importance))
#             fuzzy_similarity[i, j] = similarity
#             fuzzy_similarity[j, i] = similarity
#
#     return fuzzy_similarity
#
# def FRAR9(data, labels, threshold):
#     attribute_importance = calculate_attribute_importance(data, labels)
#     fuzzy_similarity = calculate_fuzzy_similarity(data, attribute_importance)
#
#     num_attributes = len(data[0])
#     reduct = set(range(num_attributes))
#
#     while True:
#         reduct_changed = False
#
#         for i in range(num_attributes):
#             if i not in reduct:
#                 temp_reduct = reduct.copy()
#                 temp_reduct.add(i)
#
#                 indiscernibility_matrix = np.ones((len(data), len(data)))
#                 for j in range(len(data)):
#                     for k in range(j, len(data)):
#                         indiscernibility_matrix[j, k] = min(fuzzy_similarity[j, k], indiscernibility_matrix[j, k])
#                         indiscernibility_matrix[k, j] = indiscernibility_matrix[j, k]
#
#                 positive_region = []
#                 for j in range(len(data)):
#                     if all(indiscernibility_matrix[j, k] >= threshold for k in range(len(data))):
#                         positive_region.append(j)
#
#                 if len(positive_region) == len(data):
#                     reduct.add(i)
#                     reduct_changed = True
#
#         if not reduct_changed:
#             break
#
#     return reduct


# # FRAR10：模糊相似关系用欧氏距离计算
# import numpy as np
# from scipy.spatial.distance import pdist, squareform
# from sklearn.preprocessing import MinMaxScaler
#
# def calculate_attribute_importance(data, labels):
#     # 标准化数据
#     scaler = MinMaxScaler()
#     scaled_data = scaler.fit_transform(data)
#
#     # 计算属性之间的相似度
#     pairwise_distances = squareform(pdist(scaled_data.T, metric='euclidean'))
#     attribute_similarity = 1 - pairwise_distances
#
#     # 计算属性重要度
#     num_attributes = data.shape[1]
#     attribute_importance = np.zeros(num_attributes)
#     for i in range(num_attributes):
#         attribute_importance[i] = np.mean(attribute_similarity[:, i])
#
#     return attribute_importance
#
# def calculate_fuzzy_similarities(data, attribute_importance):
#     num_instances = data.shape[0]
#     fuzzy_similarities = np.zeros((num_instances, num_instances))
#
#     for i in range(num_instances):
#         for j in range(i + 1, num_instances):
#             similarity = np.exp(-np.sum(attribute_importance * np.abs(data[i] - data[j])))
#             fuzzy_similarities[i, j] = similarity
#             fuzzy_similarities[j, i] = similarity
#
#     return fuzzy_similarities
#
# def calculate_fuzzy_rough_membership(fuzzy_similarities, threshold):
#     num_instances = fuzzy_similarities.shape[0]
#     fuzzy_rough_membership = np.zeros((num_instances, num_instances))
#
#     for i in range(num_instances):
#         for j in range(i + 1, num_instances):
#             if fuzzy_similarities[i, j] >= threshold:
#                 fuzzy_rough_membership[i, j] = 1
#                 fuzzy_rough_membership[j, i] = 1
#
#     return fuzzy_rough_membership
#
# def FRAR10(data, labels, threshold):
#     num_attributes = data.shape[1]
#     attribute_importance = calculate_attribute_importance(data, labels)
#     fuzzy_similarities = calculate_fuzzy_similarities(data, attribute_importance)
#     fuzzy_rough_membership = calculate_fuzzy_rough_membership(fuzzy_similarities, threshold)
#
#     reduct = set(range(num_attributes))
#
#     while True:
#         prev_reduct = reduct.copy()
#
#         for attribute in reduct:
#             temp_reduct = reduct.copy()
#             temp_reduct.remove(attribute)
#
#             if np.array_equal(fuzzy_rough_membership, calculate_fuzzy_rough_membership(fuzzy_similarities[:, temp_reduct], threshold)):
#                 reduct.remove(attribute)
#
#         if prev_reduct == reduct:
#             break
#
#     return reduct

##########################################################################
# # FRAR11:相关系数计算属性重要度，利用欧氏距离计算模糊相似关系
# import numpy as np
# from scipy.spatial.distance import pdist, squareform
#
# def calculate_attribute_importance(data):
#     # 计算属性重要度
#     label = data[:, -1].astype('float')  # 最后一列是标签
#     attributes = data[:, :-1].astype('float')  # 属性列
#     attribute_importance = np.zeros(attributes.shape[1])
#
#     for i in range(attributes.shape[1]):
#         attribute_values = attributes[:, i]
#         attribute_importance[i] = np.corrcoef(attribute_values, label)[0, 1]  # 使用相关系数作为属性重要度度量
#
#     return attribute_importance
#
# def calculate_fuzzy_similarity(data):
#     # 构造模糊相似关系矩阵
#     attributes = data[:, :-1].astype('float') # 属性列
#     similarity_matrix = squareform(pdist(attributes, metric='euclidean'))  # 使用欧几里得距离计算相似度
#
#     return similarity_matrix
#
# def calculate_lower_approximation(fuzzy_similarity_matrix, reduct):
#     # 计算下近似
#     num_instances = fuzzy_similarity_matrix.shape[0]
#     lower_approximation = set(range(num_instances))
#
#     for i in range(num_instances):
#         for j in range(i + 1, num_instances):
#             if (i in lower_approximation) and (j in lower_approximation):
#                 if fuzzy_similarity_matrix[i, j] < reduct:
#                     lower_approximation.discard(j)
#
#     return lower_approximation
#
# def FRAR11(data, threshold):
#     attribute_importance = abs(calculate_attribute_importance(data))
#     sorted_indices = np.argsort(attribute_importance)[::-1]  # 按照属性重要度降序排序
#     fuzzy_similarity_matrix = calculate_fuzzy_similarity(data)
#     num_attributes = data.shape[1] - 1  # 减去标签列
#
#     reduct = set()
#     for i in range(num_attributes):
#         reduct.add(sorted_indices[i])
#         lower_approximation = calculate_lower_approximation(fuzzy_similarity_matrix, threshold)
#
#         if len(lower_approximation) == len(data):
#             break
#     if len(reduct)>=10:
#         return sorted_indices[0:10]
#     return reduct


# FRAR12:它根据属性重要度和模糊相似性计算属性的增益，选择增益最大的属性作为约简的一部分。在每次选择时，还考虑了属性的粗糙度，即正域和负域之间的比例。
import numpy as np
from scipy.spatial.distance import pdist, squareform

# def calculate_attribute_importance(data):
#     # 计算属性重要度
#     label = data[:, -1].astype('float')
#     attributes = data[:, :-1].astype('float')
#     attribute_importance = np.zeros(attributes.shape[1])
#
#     for i in range(attributes.shape[1]):
#         attribute_importance[i] = np.corrcoef(attributes[:, i], label)[0, 1]
#
#     return attribute_importance
#
# def calculate_fuzzy_similarity(data):
#     # 构造模糊相似关系矩阵
#     attributes = data[:, :-1].astype('float')
#     similarity_matrix = squareform(pdist(attributes, metric='euclidean'))
#
#     # 使用高斯模糊化处理
#     sigma = np.std(similarity_matrix)
#     fuzzy_similarity_matrix = np.exp(-0.5 * np.power(similarity_matrix / sigma, 2))
#
#     return fuzzy_similarity_matrix
#
# def calculate_lower_approximation(data, reduct):
#     # 计算下近似
#     instances = data[:, :-1]
#     labels = data[:, -1]
#     lower_approximation = []
#
#     for i in range(len(instances)):
#         print(reduct)
#         subset = instances[i, reduct]
#         if np.all(subset == instances[reduct, :]):
#             lower_approximation.append(labels[i])
#
#     return lower_approximation
#
# def FRAR12(data):
#     # 计算属性重要度
#     attribute_importance = calculate_attribute_importance(data)
#
#     # 构造模糊相似关系矩阵
#     fuzzy_similarity_matrix = calculate_fuzzy_similarity(data)
#
#     # 初始化约简和属性集
#     reduct = []
#     attributes = set(range(data.shape[1] - 1))
#
#     while attributes:
#         max_gain = -np.inf
#         max_gain_attribute = None
#
#         for attribute in attributes:
#             temp_reduct = reduct + [attribute]
#             lower_approximation = calculate_lower_approximation(data, temp_reduct)
#
#             # 计算属性的粗糙度
#             positive_region = np.sum(lower_approximation)
#             negative_region = len(lower_approximation) - positive_region
#             roughness = positive_region / (positive_region + negative_region)
#
#             # 计算属性的增益
#             gain = attribute_importance[attribute] * np.mean(fuzzy_similarity_matrix[temp_reduct][:, temp_reduct]) * (1 - roughness)
#
#             if gain > max_gain:
#                 max_gain = gain
#                 max_gain_attribute = attribute
#
#         reduct.append(max_gain_attribute)
#         attributes.remove(max_gain_attribute)
#
#     return reduct


# # FRAR13:用相对信息熵计算属性重要度，用
# import numpy as np
#
# def calculate_attribute_importance(data, labels):
#     label_values, label_counts = np.unique(labels, return_counts=True)
#     total_instances = len(labels)
#
#     label_probabilities = label_counts / total_instances
#     entropy = -np.sum(label_probabilities * np.log2(label_probabilities))
#
#     attribute_importance = []
#
#     for attribute in data.T:
#         attribute_values, value_counts = np.unique(attribute, return_counts=True)
#         attribute_probabilities = value_counts / total_instances
#
#         conditional_entropy = 0.0
#
#         for value in attribute_values:
#             label_value_counts = np.zeros(len(label_values))
#
#             for i, label_value in enumerate(label_values):
#                 matching_indices = np.where((attribute == value) & (labels == label_value))[0]
#                 label_value_counts[i] = len(matching_indices)
#
#             value_probabilities = label_value_counts / np.sum(label_value_counts)
#             value_entropy = -np.sum(value_probabilities * np.log2(value_probabilities))
#
#             conditional_entropy += (attribute_probabilities[np.where(attribute_values == value)[0][0]] * value_entropy)
#
#         attribute_importance.append(entropy - conditional_entropy)
#
#     return attribute_importance
#
# def calculate_fuzzy_similarity(data):
#     num_attributes = data.shape[1]
#     similarity_matrix = np.zeros((num_attributes, num_attributes))
#
#     for i in range(num_attributes):
#         for j in range(i + 1, num_attributes):
#             diff = np.abs(data[:, i] - data[:, j])
#             similarity_matrix[i, j] = np.mean(diff)
#             similarity_matrix[j, i] = similarity_matrix[i, j]
#
#     return similarity_matrix
#
# def FRAR13(data, labels, threshold):
#     attribute_importance = calculate_attribute_importance(data, labels)
#     similarity_matrix = calculate_fuzzy_similarity(data)
#
#     num_attributes = data.shape[1]
#     reduct = set(range(num_attributes))
#
#     while True:
#         removed_attribute = None
#         max_reduction = 0.0
#
#         for attribute in reduct:
#             reduction = 0.0
#
#             for other_attribute in reduct - {attribute}:
#                 reduction += attribute_importance[other_attribute] * (1 - similarity_matrix[attribute, other_attribute])
#
#             if reduction > max_reduction:
#                 max_reduction = reduction
#                 removed_attribute = attribute
#
#         if max_reduction < threshold:
#             break
#
#         reduct.remove(removed_attribute)
#
#     return reduct


# # FRAR14:用信息熵计算相对重要度，用距离计算相似性
# import numpy as np
#
# def calculate_attribute_importance(data, labels):
#     num_attributes = data.shape[1]
#     attribute_importance = np.zeros(num_attributes)
#
#     for attribute in range(num_attributes):
#         attribute_values = data[:, attribute]
#         fuzzy_similarity = calculate_fuzzy_similarity(attribute_values, labels)
#         attribute_importance[attribute] = calculate_entropy(fuzzy_similarity)
#
#     return attribute_importance
#
# def calculate_fuzzy_similarity(attribute_values, labels):
#     num_instances = len(attribute_values)
#     fuzzy_similarity = np.zeros((num_instances, num_instances))
#
#     for i in range(num_instances):
#         for j in range(i+1, num_instances):
#             similarity = calculate_similarity(attribute_values[i], attribute_values[j])
#             fuzzy_similarity[i, j] = similarity
#             fuzzy_similarity[j, i] = similarity
#
#     return fuzzy_similarity
#
# def calculate_similarity(value1, value2):
#     # 这里可以根据具体需求定义相似度的计算方式
#     # 例如，可以使用欧氏距离或其他相似度度量方法
#     return 1 / (1 + abs(value1 - value2))
#
# def calculate_entropy(fuzzy_similarity):
#     num_instances = fuzzy_similarity.shape[0]
#     entropy = 0
#
#     for i in range(num_instances):
#         similarity_sum = np.sum(fuzzy_similarity[i])
#         if similarity_sum != 0:
#             normalized_similarity = fuzzy_similarity[i] / similarity_sum
#             entropy -= np.sum(normalized_similarity * np.log2(normalized_similarity))
#
#     return entropy
#
# def FRAR14(data, labels, threshold):
#     num_attributes = data.shape[1]
#     attribute_importance = calculate_attribute_importance(data, labels)
#
#     reduct = set(range(num_attributes))
#     max_relevance = sum(attribute_importance)
#
#     for i in range(num_attributes):
#         if attribute_importance[i] / max_relevance < threshold:
#             reduct.remove(i)
#
#     return reduct


# # FRAR15：模糊粗糙度
# import numpy as np
# from scipy.spatial.distance import cdist
#
# def calculate_attribute_importance(data):
#     # 计算属性重要度，这里使用属性与标签之间的相关性作为属性重要度的度量
#     label = data[:, -1].astype('float')  # 最后一列是标签
#     attributes = data[:, :-1].astype('float')  # 属性列
#     attribute_importance = np.zeros(attributes.shape[1])
#
#     for i in range(attributes.shape[1]):
#         attribute_values = attributes[:, i]
#         attribute_importance[i] = np.corrcoef(attribute_values, label)[0, 1]  # 使用相关系数作为属性重要度度量
#
#     return attribute_importance
#
# def calculate_fuzzy_similarity(data):
#     # 构造模糊相似关系矩阵
#     attributes = data[:, :-1].astype('float')
#     similarity_matrix = 1 / (1 + cdist(attributes, attributes))
#
#     return similarity_matrix
#
# def FRAR15(data, threshold):
#     attribute_importance = calculate_attribute_importance(data)
#     similarity_matrix = calculate_fuzzy_similarity(data)
#
#     num_attributes = len(attribute_importance)
#     attributes = set(range(num_attributes))
#     reduct = set()
#
#     while True:
#         max_importance = -1
#         max_importance_attribute = None
#
#         for attribute in attributes:
#             temp_reduct = reduct.copy()
#             temp_reduct.add(attribute)
#
#             # 计算约简属性集合与非约简属性集合之间的模糊粗糙关系
#             pos_approximation = np.max(similarity_matrix[:, list(temp_reduct)], axis=1)
#             neg_approximation = np.max(similarity_matrix[:, list(attributes - temp_reduct)], axis=1)
#
#             # 计算模糊粗糙度
#             fuzzy_roughness = np.mean(np.maximum(0, pos_approximation - neg_approximation))
#
#             if fuzzy_roughness > max_importance:
#                 max_importance = fuzzy_roughness
#                 max_importance_attribute = attribute
#
#         if max_importance < threshold:
#             break
#
#         reduct.add(max_importance_attribute)
#         attributes.remove(max_importance_attribute)
#
#     return reduct


# # FRAR16:信息熵计算重要性，余弦相似度计算模糊相似关系
# import numpy as np
# from sklearn.metrics.pairwise import cosine_similarity
#
# def calculate_entropy(labels):
#     unique_labels, counts = np.unique(labels, return_counts=True)
#     probabilities = counts / len(labels)
#     entropy = -np.sum(probabilities * np.log2(probabilities))
#     return entropy
#
# def calculate_attribute_importance(data, labels):
#     attribute_importance = []
#     num_attributes = len(data[0])
#
#     for attribute in range(num_attributes):
#         attribute_values = data[:, attribute]
#         attribute_entropy = calculate_entropy(labels)
#         weighted_entropies = []
#
#         for value in np.unique(attribute_values):
#             subset_labels = labels[attribute_values == value]
#             subset_entropy = calculate_entropy(subset_labels)
#             weight = len(subset_labels) / len(labels)
#             weighted_entropies.append(weight * subset_entropy)
#
#         attribute_importance.append(attribute_entropy - sum(weighted_entropies))
#
#     return attribute_importance
#
# def calculate_fuzzy_similarity(data):
#     num_instances = len(data)
#     fuzzy_similarity = np.zeros((num_instances, num_instances))
#
#     for i in range(num_instances):
#         for j in range(i + 1, num_instances):
#             similarity = cosine_similarity([data[i]], [data[j]])
#             fuzzy_similarity[i, j] = similarity
#             fuzzy_similarity[j, i] = similarity
#
#     return fuzzy_similarity
#
# def FRAR16(data, labels, threshold):
#     num_instances = len(data)
#     num_attributes = len(data[0])
#
#     attribute_importance = calculate_attribute_importance(data, labels)
#     fuzzy_similarity = calculate_fuzzy_similarity(data)
#
#     selected_attributes = set(range(num_attributes))
#     removed_attributes = set()
#
#     while True:
#         dependency = set(range(num_instances))
#
#         for i in range(num_attributes):
#             if i in selected_attributes:
#                 selected_attributes.remove(i)
#                 reduct_similarity = calculate_fuzzy_similarity(data[:, list(selected_attributes)])
#                 similarity_difference = fuzzy_similarity - reduct_similarity
#                 consistency = np.sum(similarity_difference, axis=1)
#                 consistency_threshold = np.percentile(consistency, threshold)
#                 dependency = set(np.where(consistency >= consistency_threshold)[0])
#                 selected_attributes.add(i)
#                 if len(dependency) == num_instances:
#                     removed_attributes.add(i)
#
#         if removed_attributes:
#             selected_attributes.difference_update(removed_attributes)
#             removed_attributes.clear()
#         else:
#             break
#     # if len(selected_attributes)>10:
#     #     selected_attributes=selected_attributes[:10]
#     return list(selected_attributes)


# # FRAR17:模糊依赖度:模糊依赖度计算属性重要度，然后利用
# def calculate_similarity_matrix(data):
#     # 计算属性之间的相似关系矩阵
#     num_attributes = data.shape[1] - 1
#     similarity_matrix = np.zeros((num_attributes, num_attributes))
#
#     for i in range(num_attributes):
#         for j in range(i + 1, num_attributes):
#             # 计算属性i和属性j之间的相似度
#             similarity = calculate_similarity(data[:, i], data[:, j])
#             similarity_matrix[i, j] = similarity
#             similarity_matrix[j, i] = similarity
#
#     return similarity_matrix
#
# def calculate_similarity(x, y):
#     # 计算属性x和属性y之间的相似度
#     # 这里可以根据具体问题选择合适的相似度度量方法
#     # 这里以余弦相似度作为示例
#     dot_product = np.dot(x, y)
#     norm_x = np.linalg.norm(x)
#     norm_y = np.linalg.norm(y)
#
#     similarity = dot_product / (norm_x * norm_y)
#     return similarity
#
# def calculate_fuzzy_dependency(data, attribute_index):
#     # 计算属性attribute_index的模糊依赖度
#     num_instances = data.shape[0]
#     attribute_values = data[:, attribute_index]
#     labels = data[:, -1]
#
#     # 计算模糊依赖度
#     fuzzy_dependency = 0.0
#     for i in range(num_instances):
#         for j in range(i + 1, num_instances):
#             if labels[i] != labels[j]:
#                 fuzzy_dependency += abs(attribute_values[i] - attribute_values[j])
#
#     fuzzy_dependency /= num_instances * (num_instances - 1) / 2
#
#     return fuzzy_dependency
#
# def FRAR17(data, num_selected_attributes):
#     # 属性约简算法
#     num_attributes = data.shape[1] - 1
#
#     # 构造模糊相似关系矩阵
#     similarity_matrix = calculate_similarity_matrix(data)
#
#     # 初始化属性重要度列表
#     attribute_importance = np.zeros(num_attributes)
#
#     # 计算每个属性的模糊依赖度
#     for i in range(num_attributes):
#         attribute_importance[i] = calculate_fuzzy_dependency(data, i)
#
#     # 根据属性重要度排序
#     sorted_indices = np.argsort(attribute_importance)
#     selected_attributes = sorted_indices[-num_selected_attributes:]
#
#     return selected_attributes


#
# #FRAR18：计算相似度，然后计算属性重要度，是用相似度求和计算
# # 构造模糊相似关系矩阵
# def construct_fuzzy_similarity_matrix(data):
#     n = len(data)
#     similarity_matrix = np.zeros((n, n))
#
#     for i in range(n):
#         for j in range(i+1, n):
#             # 这里可以根据具体问题设计模糊相似关系的计算方法
#             similarity_matrix[i][j] = calculate_fuzzy_similarity(data[i], data[j])
#             similarity_matrix[j][i] = similarity_matrix[i][j]
#
#     return similarity_matrix
#
# # 计算模糊相似度
# def calculate_fuzzy_similarity(instance1, instance2):
#     # 这里可以根据具体问题设计模糊相似度的计算方法
#     # 假设 instance1 和 instance2 是一维实值向量
#     similarity = 1.0 / (1.0 + abs(instance1 - instance2))
#     return similarity
#
# # 计算属性重要度
# def calculate_attribute_importance(data, labels):
#     n_attributes = len(data[0])
#     attribute_importance = np.zeros(n_attributes)
#
#     for i in range(n_attributes):
#         attribute_values = data[:, i]
#         attribute_importance[i] = np.sum(calculate_fuzzy_similarity(labels, attribute_values))
#
#     return attribute_importance
#
# # 模糊粗糙集属性约简算法
# def FRAR18(data, labels, threshold):
#     n_instances, n_attributes = data.shape
#     all_attributes = set(range(n_attributes))
#
#     attribute_importance = calculate_attribute_importance(data, labels)
#     sorted_attributes = np.argsort(attribute_importance)[::-1]
#
#     selected_attributes = set()
#     for attribute in sorted_attributes:
#         selected_attributes.add(attribute)
#         if len(selected_attributes) == n_attributes:
#             break
#
#         lower_approximation = get_lower_approximation(data, labels, selected_attributes)
#         if len(lower_approximation) == n_instances:
#             selected_attributes.remove(attribute)
#         elif calculate_roughness(lower_approximation) <= threshold:
#             break
#
#     return selected_attributes
#
# # 计算粗糙度
# def calculate_roughness(lower_approximation):
#     return len(lower_approximation)
#
# # 获取下近似集合
# def get_lower_approximation(data, labels, selected_attributes):
#     n_instances = len(data)
#     lower_approximation = set(range(n_instances))
#
#     for i in range(n_instances):
#         for j in range(i+1, n_instances):
#             if labels[i] != labels[j]:
#                 consistent = True
#                 for attribute in selected_attributes:
#                     if data[i][attribute] != data[j][attribute]:
#                         consistent = False
#                         break
#                 if consistent:
#                     lower_approximation.discard(j)
#
#     return lower_approximation
#


# FRAR19:利用模糊依赖度计算模糊相似性
def calculate_dependency_matrix(data):
    num_attributes = data.shape[1] - 1  # 属性的数量
    num_instances = data.shape[0]  # 实例的数量

    dependency_matrix = np.zeros((num_attributes, num_attributes))  # 初始化依赖度矩阵

    # 计算属性之间的依赖度
    for i in range(num_attributes):
        for j in range(num_attributes):
            if i != j:
                # 计算属性i和属性j之间的依赖度
                dependency = 0.0
                for k in range(num_instances):
                    diff = abs(data[k][i] - data[k][j])  # 计算属性值之间的差异
                    dependency += diff
                dependency /= num_instances
                dependency_matrix[i][j] = dependency

    return dependency_matrix


def calculate_attribute_importance(dependency_matrix):
    num_attributes = dependency_matrix.shape[0]
    attribute_importance = np.zeros(num_attributes)  # 初始化属性重要度向量

    # 计算属性的重要度
    for i in range(num_attributes):
        importance = np.sum(dependency_matrix[i])
        attribute_importance[i] = importance

    return attribute_importance


def construct_fuzzy_similarity_matrix(attribute_importance):
    num_attributes = attribute_importance.shape[0]
    fuzzy_similarity_matrix = np.zeros((num_attributes, num_attributes))

    # 构造模糊相似关系矩阵
    for i in range(num_attributes):
        for j in range(num_attributes):
            if i != j:
                similarity = min(attribute_importance[i], attribute_importance[j]) / max(attribute_importance[i],
                                                                                            attribute_importance[j])
                fuzzy_similarity_matrix[i][j] = similarity

    return fuzzy_similarity_matrix


def FRAR19(data,threshold):
    num_attributes = data.shape[1] - 1  # 属性的数量

    dependency_matrix = calculate_dependency_matrix(data)  # 计算依赖度矩阵
    attribute_importance = calculate_attribute_importance(dependency_matrix)  # 计算属性重要度
    fuzzy_similarity_matrix = construct_fuzzy_similarity_matrix(attribute_importance)  # 构造模糊相似关系矩阵

    # 初始化属性约简列表
    attribute_reduction = list(range(num_attributes))

    # 逐个属性进行约简
    for i in range(num_attributes):
        if i in attribute_reduction:
            for j in range(num_attributes):
                if j != i and j in attribute_reduction:
                    # 判断属性i和属性j是否具有相似关系
                    if fuzzy_similarity_matrix[i][j] >=threshold :
                        attribute_reduction.remove(j)  # 移除与属性i相似的属性j

    return attribute_reduction





ReadAddress=r"H:\PythonProject\MachineLearning\FoodSecurity\Data\ProcessingData\InitialData\InitialData_Normalized.xlsx"
fm=pd.read_excel(ReadAddress,sheet_name=None,index_col=0)
province='河北'
df=fm[province]
feathers=df.columns
X=df.iloc[1:,1:-1]
y=df['每亩主产品产量'][1:]
X=X.values
y=y.values
# result=FRAR18(X, y,0.9)
# print(result)
# print(feathers[result])

y = np.expand_dims(y, axis=1)
data=np.concatenate((X, y), axis=1)
result=FRAR19(data,0.99)
print(result)
# print(feathers[result])


# .astype('float')
