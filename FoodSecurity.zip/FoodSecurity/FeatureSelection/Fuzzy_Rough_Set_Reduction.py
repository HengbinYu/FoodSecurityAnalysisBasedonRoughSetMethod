import pandas as pd
import numpy as np
import os
import time
from timeit import default_timer as timer

def dep(a, b, D):
    """
    计算属性a与属性b之间条件概率依赖度的函数
    """
    n = D.shape[0]
    p1 = sum(D[:, a] * D[:, b]) / n
    p2 = sum(D[:, a]) / n
    p3 = sum(D[:, b]) / n
    return (p1 - p2 * p3) / (min(p2, p3) - p2 * p3)

# 计算属性a的不确定度
# 计算独立性不确定度，可以评估属性 A 对分类结果的贡献程度，如果 ind(A, D) 越大，说明 A 对分类结果的贡献越大，A 对分类结果的影响越不确定.
def ind(a, D):
    n = D.shape[0]
    p = sum(D[:, a]) / n
    return 2 * p * (1 - p)

# 计算属性a的相对重要度
def importance(a, D):
    return dep(a, -1, D) - ind(a, D)

# 基于依赖度的模糊粗糙集属性约简算法
def fuzzy_rough_set_reduction(D, k):
    D=D.values
    A = np.arange(D.shape[1] - 1)
    rank_list = sorted([(importance(a, D), a) for a in A], reverse=True)
    return [a[1] for a in rank_list[:k]]

FileDirectory=os.getcwd()
ReadAddress=r"H:\PythonProject\MachineLearning\FoodSecurity\Data\ProcessingData\InitialData\InitialData_Normalized.xlsx"
ReadAddress2=r"H:\PythonProject\MachineLearning\FoodSecurity\Data\ProcessingData\InitialData\InitialData.xlsx"
WriteAddress=FileDirectory + r'\ReducedFeatures_FRAR.xlsx'
WriteAddress2=FileDirectory + r'\ReducedData_FRAR.xlsx'
WriteAddress3=FileDirectory + r'\RunningTime_FRAR.xlsx'
fm=pd.read_excel(ReadAddress,sheet_name=None,index_col=0)
fm2=pd.read_excel(ReadAddress2,sheet_name=None,index_col=0)
writer = pd.ExcelWriter(WriteAddress)
writer2 = pd.ExcelWriter(WriteAddress2)
writer3 = pd.ExcelWriter(WriteAddress3)
AllProvince=fm.keys()
ReducedFeatures=pd.DataFrame()
ConsumingTime=pd.Series()
for province in AllProvince:
    df=fm[province]
    print(province)
    X=df.iloc[1:,1:-1]
    y=df['每亩主产品产量'][1:]
    start_time = timer()
    data=pd.concat([X,y],axis=1)
    num_features = 10
    result=fuzzy_rough_set_reduction(data,num_features)
    end_time = timer()
    run_time=end_time-start_time
    ConsumingTime[province]=run_time
    top_features_idx = result[:num_features]
    top_features=X.columns[top_features_idx]
    Temp=pd.Series(top_features)
    Temp.rename(province,inplace=True)
    ReducedFeatures=pd.concat([ReducedFeatures,Temp],axis=1)
    df2=fm2[province]
    selected_data=df2.iloc[:,top_features_idx]
    selected_data=pd.concat([selected_data,df2['每亩主产品产量']],axis=1)
    selected_data=selected_data.iloc[1:,:]
    selected_data.to_excel(writer2,sheet_name=province)
    print("Top {} features: {}".format(num_features, X.columns[top_features_idx]))
writer2.save()
ColumnName = [f'feature {i}' for i in range(1, num_features+1)]
ReducedFeatures=ReducedFeatures.T
ReducedFeatures = ReducedFeatures.rename(columns=dict(zip(ReducedFeatures.columns, ColumnName)))
ReducedFeatures.to_excel(writer)
writer.save()
print(ConsumingTime)
ConsumingTime.rename('特征选择耗时',inplace=True)
ConsumingTime.to_excel(writer3,sheet_name='FuzzyRoughAttributeReduction')
writer3.save()
