from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
import pandas as pd

ReadAddress=r"H:\PythonProject\MachineLearning\FoodSecurity\Data\ProcessingData\InitialData\InitialData_Normalized.xlsx"
fm=pd.read_excel(ReadAddress,sheet_name=None,index_col=0)
province='河北'
df=fm[province]
X=df.iloc[1:,1:-1]
y=df['每亩主产品产量'][1:]

# 训练随机森林模型
rf = RandomForestRegressor(n_estimators=100, random_state=42)
rf.fit(X, y)

# 特征选择
importances = rf.feature_importances_

# 获取前10个影响最大的特征
num_features = 10
top_features_idx = importances.argsort()[-num_features:][::-1]

# 输出结果
print("Top {} features: {}".format(num_features, X.columns[top_features_idx]))
