import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler


def fuzzy_membership_function_1(x):
    if x < 0.2:
        fuzzy_membership = 1
    elif x > 0.4:
        fuzzy_membership = 0
    else:
        fuzzy_membership = 2 - 5 * x
    return fuzzy_membership


def fuzzy_membership_function_2(x):
    if x < 0.3:
        fuzzy_membership = 0
    elif x > 0.7:
        fuzzy_membership = 0
    elif (x >= 0.3 and x < 0.5):
        fuzzy_membership = 5 * x - 1.5
    else:
        fuzzy_membership = 3.5 - 5 * x
    return fuzzy_membership


def fuzzy_membership_function_3(x):
    if x < 0.6:
        fuzzy_membership = 0
    elif x > 0.8:
        fuzzy_membership = 1
    else:
        fuzzy_membership = 5 * x - 3
    return fuzzy_membership



ReadAddress = r"H:\PythonProject\MachineLearning\FoodSecurity\Data\ProcessingData\InitialData\InitialData_Normalized.xlsx"
fm = pd.read_excel(ReadAddress, sheet_name=None, index_col=0)
province = '河北'
df = fm[province]
feathers = df.columns
X = df.iloc[1:, 1:-1]
y = df['每亩主产品产量'][1:]
max_val = y.max()
min_val = y.min()
y_norm = (y - min_val) / (max_val - min_val)
data = pd.concat([X, y_norm], axis=1)
num_features = X.shape[1]
num_instance = X.shape[0]
num_class = 3
fuzzy_table1 = data.applymap(fuzzy_membership_function_1)
fuzzy_table2 = data.applymap(fuzzy_membership_function_2)
fuzzy_table3 = data.applymap(fuzzy_membership_function_3)
# print(fuzzy_table1)
fuzzy_table = [fuzzy_table1, fuzzy_table2, fuzzy_table3]
# print(fuzzy_table)

# importance=dict()
importance = list()
for index_attribute in range(num_features):
    # 计算每个属性的重要度，即计算决策属性Q对各个条件属性的模糊依赖度
    fuzzy_lower_approximation = list()  # 存储该属性在不同决策内里的模糊下近似
    for index in range(num_class):
        # 计算该属性在不同决策类里的模糊下近似
        attr_c = fuzzy_table[index].iloc[:, index_attribute]
        attr_d = fuzzy_table[index].iloc[:, -1]
        df_attr = pd.concat([1 - attr_c, attr_d], axis=1)
        inf_sup_df = df_attr.max(axis=1).min(axis=0)
        fuzzy_lower_approximation.append(inf_sup_df)

    POS_membership = list()  # 存储每个对象对于模糊正域的隶属度
    for index_instance in range(num_instance):
        # 计算每个对象对该条件属性的模糊正域的隶属度
        class_d_membership = list()  # 存储该对象在不同决策类下的隶属度
        for index_class in range(num_class):
            # 计算该对象对每个决策类的隶属度
            ind_membership = list()
            for index in range(num_class):
                # 计算每个对象在各个等价类下对每个决策类的隶属度
                temp = min(fuzzy_lower_approximation[index_class],
                           fuzzy_table[index].iloc[index_instance, index_attribute])
                ind_membership.append(temp)
            temp_class = max(ind_membership)
            class_d_membership.append(temp_class)
        instance_POS_membership = max(class_d_membership)
        POS_membership.append(instance_POS_membership)
    # print(POS_membership)
    fuzzy_dependence = sum(POS_membership) / num_instance
    # importance[feathers[index_attribute]]=fuzzy_dependence
    importance.append(fuzzy_dependence)
# sort_importance=dict(sorted(importance.items(), key=lambda x: x[1], reverse=True))
print(importance)
# print(sort_importance)
