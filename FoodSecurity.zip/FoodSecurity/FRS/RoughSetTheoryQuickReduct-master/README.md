This is a python code for feature selection
