# QR-python
quick reduct Feature selection 
This is a python implementation of the Quickreduct algorithm (feature selection based of rough set)
