import numpy as np
import skfuzzy as fuzz
import pandas as pd
# 决策表的属性值（假设已准备好）
# 将属性值以18x27的形式存储在一个numpy数组中
# decision_table = np.random.rand(18, 27)

def min_max_scaler(x):
    return (x - x.min()) / (x.max() - x.min())

ReadAddress=r"H:\PythonProject\MachineLearning\FoodSecurity\Data\ProcessingData\InitialData\InitialData_Normalized.xlsx"
fm=pd.read_excel(ReadAddress,sheet_name=None,index_col=0)
AllProvince=fm.keys()
CategoriesNumber=dict()
for province in AllProvince:
# province='黑龙江'
    df=fm[province]
    feathers=df.columns
    X=df.iloc[1:,1:-1]
    y=df['每亩主产品产量'][1:]
    y_max=max(y)
    y_min=min(y)
    y_normalized = (y-y_min)/(y_max-y_min)
    X=X.values
    # print(y_normalized)
    y = np.expand_dims(y, axis=1)
    data=np.concatenate((X, y), axis=1).astype('float')
    # 执行模糊C均值聚类
    # 假设要确定2到10个模糊等价类之间的最佳个数
    min_clusters = 2
    max_clusters = 5

    best_num_clusters = None
    best_membership = None
    best_cluster_centers = None
    best_cluster_labels = None
    best_cluster_score = float('-inf')

    for num_clusters in range(min_clusters, max_clusters + 1):
        # 计算模糊聚类
        cntr, u, u0, d, jm, p, fpc = fuzz.cluster.cmeans(
            data.T, num_clusters, 2, error=0.000005, maxiter=1000000)

        # 计算聚类分数
        cluster_score = fpc

        # 检查当前聚类分数是否更好
        if cluster_score > best_cluster_score:
            best_cluster_score = cluster_score
            best_num_clusters = num_clusters
            best_membership = u
            best_cluster_centers = cntr
            best_cluster_labels = np.argmax(u, axis=0)

    # 输出最佳的模糊等价类个数
    # print("最佳模糊等价类个数：", best_num_clusters)
    print(province,":", best_num_clusters)
    CategoriesNumber[province]=best_num_clusters

print(np.array(list(CategoriesNumber.values())).mean())
