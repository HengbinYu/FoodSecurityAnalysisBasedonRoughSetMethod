import matplotlib.pyplot as plt
plt.rcParams['font.family'] = ['SimHei']
# 定义数据点
x1 = 0.2
x2 = 0.5
x3 = 0.8

# 绘制折线图
plt.plot([x1, x2, x3], [0, 1, 0])

# 设置坐标范围
plt.xlim(0, 1)
plt.ylim(0, 1)

# 设置坐标轴标签
plt.xlabel('a(x)')
plt.ylabel('μ(x)')

# 显示图形
plt.show()
