import os
import re
import time
import requests
import random

from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
import requests as req
import threading
import time
from bs4 import BeautifulSoup
from fake_useragent import UserAgent
from lxml import etree as et


start_url ='https://data.cnki.net/yearBook/single?nav=&id=N2022110021'

resp = req.get(start_url, UserAgent().random)
# resp.encoding = 'utf-8'  # 此页面编码方式为 GBK，设置为 utf-8 同样也会乱码
soup = BeautifulSoup(resp.text, "lxml")  # 效率快
print(soup)
url_set=soup.find("body")
print(url_set)


#
# options = webdriver.FirefoxOptions()
# options.add_argument("--headless")
# driver = webdriver.Firefox(options=options)
# driver.get(url)
# cookies = driver.get_cookies()
# driver.quit()
# def _cookie_to_string(cookies):
#     string = ''
#     for cookie in cookies:
#         string += '{}={}; '.format(cookie['name'], cookie['value'])
#     return string.strip()
# # return _cookie_to_string(cookies)
